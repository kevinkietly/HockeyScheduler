create package     PRVT_DBMS_MANAGE_XMLSTORAGE wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
137 eb
/e0W8RAwooIABognR9LW5cxkuoowg5BKAMvWfHQC2seeKKQYwzJ9l5GsOsy3yHs5Avr+nem2
RmmxPCX95OQ6MfvXmVus3QoRsUVNyxDfIa39AYtlalRcpnMG8FkDBzfbR9FU8sJEZgxKNLQ+
8kD/RUQAymKJZYFpiQsMD2p4RxSZElpM+IVFHFkxs/EKJeTHJLz+BFT31+PkNGq56YLxaus7
qs8aZpoqnCh8LK4R
/

