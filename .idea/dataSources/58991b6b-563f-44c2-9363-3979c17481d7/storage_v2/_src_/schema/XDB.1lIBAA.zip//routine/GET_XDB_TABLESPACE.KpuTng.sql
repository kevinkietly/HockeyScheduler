create FUNCTION     get_xdb_tablespace wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
f3 107
yGrBq9SjQ7pfVFABbFo0k+ST6bYwgwFK7csVfHRGWPiOHMhFf0tgdDp/oE0u3dwOWcyZlJkd
06QwzwkYRjYlLryYcsTLK/glk1MzhM+HRVegVTuqaAXHKEYiyALWFExao6xddA6gOf2WXAI0
t6v73U3shiJX0BunYJGeeGMu+qFflCcommCgwtRGCLnQDRvqHU8w8wQ+ew0u11c67/xUymMH
u2qikzUZBCpJkR9aC9HCjvhH+TdtUsuj78mW0cRneQ==
/

