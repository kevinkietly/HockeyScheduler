create view USER_WM_VERSIONED_TABLES as
select t.table_name, t.owner,
       disabling_ver state,
       t.hist history,
       decode(t.notification, 0, 'NO', 1, 'YES') notification,
       substr(notifyWorkspaces,2,length(notifyworkspaces)-2) notifyworkspaces,
       wmsys.owm_dynsql_access.AreThereConflicts(t.owner, t.table_name, t.vtid) conflict,
       wmsys.owm_dynsql_access.AreThereDiffs(t.owner, t.table_name, t.vtid) diff,
       decode(t.validtime, 0, 'NO', 1, 'YES') validtime
from wmsys.wm$versioned_tables t
where t.owner = sys_context('userenv', 'current_user')
WITH READ ONLY
/

