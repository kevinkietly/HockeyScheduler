create view USER_WM_VT_ERRORS as
select vt.owner,vt.table_name,vt.state,vt.sql_str,et.status,et.error_msg
from (select t1.owner, t1.table_name, t1.disabling_ver state, nt.index_type, nt.index_field, dbms_lob.substr(nt.sql_str,4000,1) sql_str
      from wmsys.wm$versioned_tables t1, table(t1.undo_code) nt) vt,
     wmsys.wm$vt_errors_table et
where vt.owner = et.owner and
      vt.table_name = et.table_name and
      vt.index_type = et.index_type and
      vt.index_field = et.index_field and
      vt.owner = sys_context('userenv', 'current_user')
WITH READ ONLY
/

