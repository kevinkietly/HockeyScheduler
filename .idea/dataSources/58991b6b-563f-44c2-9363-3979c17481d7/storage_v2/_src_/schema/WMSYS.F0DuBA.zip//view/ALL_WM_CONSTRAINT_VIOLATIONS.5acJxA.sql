create view ALL_WM_CONSTRAINT_VIOLATIONS as
select t.code violation#, t.vfield1 table_name1, substr(t.vfield3, 1, instr(t.vfield3, '|')-1) predicate1, t.nfield1 version1,
                          t.vfield2 table_name2, substr(t.vfield3, instr(t.vfield3, '|')+1) predicate2, t.nfield2 version2
from table(wmsys.owm_dynsql_access.returnConstraintViolations) t
WITH READ ONLY
/

