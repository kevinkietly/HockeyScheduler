create FUNCTION         to_lbac_label wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
22e 11f
zoWQ+6ztlIHHd0jWO/Aos8eA84cwg5XILZ4VZ3RnkLvVZSsvW7EGuO3osdZ1p5gKj/WgBiu4
CLUIgxgyUFG3k+bKlkKhs0ub6OBTTISaDcFQxFVjH6V/8UVmjNw3Q/uvfHZjXGOgmNfhhGWE
nv+6apJ41AwAjvcm+kRqHCqjhS3IskKPQBFiVpLUZWkbjdq+zchqWpmGokCDuHELnlqL9/i9
RA9m0MvQiLyegiLiA1YpgV1sQ7/BP+skRRot8/rutTJBIOxuV9ByDOlHKfzLOv8ySA==
/

