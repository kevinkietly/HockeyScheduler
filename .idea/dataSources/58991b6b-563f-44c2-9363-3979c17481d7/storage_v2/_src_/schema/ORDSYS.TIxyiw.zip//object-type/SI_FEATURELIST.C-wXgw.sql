create TYPE SI_FeatureList
                                                                          
  AUTHID CURRENT_USER
  AS OBJECT
  (
   --attributes
   --The attribute names have a _SI suffix instead of SI_ prefix
   --because RDBMS does not allows attributes name and function
   --name to be the same.
   --IMPORTANT NOTE!!!!
   -- DO NOT change the order of the attributes
   -- DO NOT change the attribute names
   -- This constructor functions OVERRIDES and HIDES the SYSTEM DEFAULT
   -- constructor. This is done so that we can perform the necessary error
   -- checking to raise the appropriate error message in the constructor
   --
   --  To do this the attribute names
   -- and order of the attributes must be exactly like it is defined here
   AvgClrFtr_SI         SI_AverageColor,
   AvgClrFtrWght_SI     DOUBLE PRECISION,
   ClrHstgrFtr_SI       SI_ColorHistogram,
   ClrHstgrFtrWght_SI   DOUBLE PRECISION,
   PstnlClrFtr_SI       SI_PositionalColor,
   PstnlClrFtrWght_SI   DOUBLE PRECISION,
   TextureFtr_SI        SI_Texture,
   TextureFtrWght_SI    DOUBLE PRECISION,
   --
   --NOTE: The arguments of this constructor function name MUST
   -- match the attribute names defined above to be able to OVERRIDE the
   --SYSTEM DEFAULT constructor.
   CONSTRUCTOR FUNCTION SI_FeatureList
     (AvgClrFtr_SI             IN  SI_AverageColor,
      AvgClrFtrWght_SI         IN  DOUBLE PRECISION,
      ClrHstgrFtr_SI           IN  SI_ColorHistogram,
      ClrHstgrFtrWght_SI       IN  DOUBLE PRECISION,
      PstnlClrFtr_SI           IN  SI_PositionalColor,
      PstnlClrFtrWght_SI       IN  DOUBLE PRECISION,
      TextureFtr_SI            IN  SI_Texture,
      TextureFtrWght_SI        IN  DOUBLE PRECISION)
     return SELF AS RESULT DETERMINISTIC,

     --
     MEMBER PROCEDURE SI_setFeature
     (SELF IN OUT NOCOPY SI_FeatureList,
     averageColorFeature         IN  SI_AverageColor,
     averageColorFeatureWeight    IN  DOUBLE PRECISION),
     --
     MEMBER PROCEDURE SI_setFeature
     (SELF IN OUT NOCOPY SI_FeatureList ,
     colorHistogramFeature        IN  SI_ColorHistogram,
     colorHistogramFeatureWeight  IN  DOUBLE PRECISION),
     --
     MEMBER PROCEDURE SI_setFeature
     (SELF IN OUT NOCOPY SI_FeatureList ,
     positionalColorFeature       IN  SI_PositionalColor,
     positionalColorFeatureWeight IN  DOUBLE PRECISION),
     --
     MEMBER PROCEDURE SI_setFeature
     (SELF IN OUT NOCOPY SI_FeatureList,
     textureFeature               IN  SI_Texture,
     textureFeatureWeight         IN  DOUBLE PRECISION),
     --
     MEMBER FUNCTION SI_Score
     (SELF  IN SI_FeatureList,
      image IN SI_StillImage)
       RETURN DOUBLE PRECISION DETERMINISTIC,
     --
     MEMBER FUNCTION SI_AvgClrFtr(SELF IN SI_FeatureList)
     RETURN SI_AverageColor DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_AvgClrFtr, WNDS, WNPS, RNDS, RNPS),
     --
     MEMBER FUNCTION SI_AvgClrFtrWght(SELF IN SI_FeatureList)
     RETURN DOUBLE PRECISION DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_AvgClrFtrWght, WNDS, WNPS, RNDS, RNPS),
     --
     MEMBER FUNCTION SI_ClrHstgrFtr(SELF IN SI_FeatureList)
     RETURN SI_ColorHistogram DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_ClrHstgrFtr, WNDS, WNPS, RNDS, RNPS),
     --
     MEMBER FUNCTION SI_ClrHstgrFtrWght(SELF IN SI_FeatureList)
     RETURN DOUBLE PRECISION DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_ClrHstgrFtrWght, WNDS, WNPS, RNDS, RNPS),
     --
     MEMBER FUNCTION SI_PstnlClrFtr(SELF IN SI_FeatureList)
     RETURN SI_PositionalColor DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_PstnlClrFtr, WNDS, WNPS, RNDS, RNPS),
     --
     MEMBER FUNCTION SI_PstnlClrFtrWght(SELF IN SI_FeatureList)
     RETURN DOUBLE PRECISION DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_PstnlClrFtrWght, WNDS, WNPS, RNDS, RNPS),
     --
     MEMBER FUNCTION SI_TextureFtr(SELF IN SI_FeatureList)
     RETURN SI_Texture DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_TextureFtr, WNDS, WNPS, RNDS, RNPS),
     --
     MEMBER FUNCTION SI_TextureFtrWght(SELF IN SI_FeatureList)
     RETURN DOUBLE PRECISION DETERMINISTIC,
       PRAGMA RESTRICT_REFERENCES(SI_TextureFtrWght, WNDS, WNPS, RNDS, RNPS)
     --
) INSTANTIABLE
  NOT FINAL;
/

