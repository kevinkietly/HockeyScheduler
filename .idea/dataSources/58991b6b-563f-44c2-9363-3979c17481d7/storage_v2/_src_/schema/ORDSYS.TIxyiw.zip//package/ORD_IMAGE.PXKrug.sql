create PACKAGE        ORD_IMAGE AUTHID CURRENT_USER AS
---------------------------
-- FUNCTIONS AND PROCEDURES
---------------------------
--  Description: Copies multimedia data from BLOBs within the database to an
--  external data source.
--  Input:
--    src: The BLOB location of the data to be exported (or copied) to the
--    destination location
--    dest_location: The location to which the source data is to be exported.
--    (File directory object)
--    dest_name: The name of the destination file.
--    Exceptions: ORDSourceExceptions.INCOMPLETE_SOURCE_INFORMATION
--    ORDSourceExceptions.IO_ERROR

  PROCEDURE  export (
	src IN BLOB,
	dest_location IN VARCHAR2,
	dest_name IN VARCHAR2
	);

--  Description: Import data from the specified external data source to the BLOB
--   specified by the dest parameter.
--  Input:
--    dest: The BLOB location to receive the data
--    source_type: The type of the source data.  (FILE or URL)
--    source_location: The location from which the source data is to be imported.
--    source_name: The name of the source data.
--    Exceptions:ORDSourceExceptions.NULL_SOURCE

  PROCEDURE  importFrom (
	dest IN OUT NOCOPY BLOB,
	source_type IN VARCHAR2,
	source_location IN VARCHAR2,
	source_name IN VARCHAR2
	);

--  Description: Import data from the specified external data source to the BLOB
--  specified by the dest parameter.
--  Input:
--    dest: The BLOB location to receive the data
--    source_type: The type of the source data.  (FILE or URL)
--    source_location: The location from which the source data is to be imported.
--    source_name: The name of the source data.
--    format: The format of the data.
--    mime_type: The MIME type of the data.
--    Exceptions:ORDSourceExceptions.NULL_SOURCE

  PROCEDURE  importFrom (
	dest IN OUT NOCOPY BLOB,
	source_type IN VARCHAR2,
	source_location IN VARCHAR2,
	source_name IN VARCHAR2,
	format OUT VARCHAR2,
	mime_type OUT VARCHAR2
	);

--  Description: Overlays an image watermark onto a source image stored in a
--  BFILE and writes it to a destination BLOB.
--  Input:
--    imageBfile: The source image data represented as BFILE.
--    added_image: The watermark image stored in a BFILE to be added to the
--    source image.
--    dest: The destination BLOB for the watermarked image.
--    logging: A string that contains information about any unexpected behavior
--    that occurred during the watermarking operation.  If the operation is
--    successful, an empty string is returned.
--    watermark_properties: A string list of name-value pairs that define
--    attributes of the watermark image, including: width, height, position,
--    position_x, position_y, and transparency.
--    Exceptions: ORDImageExceptions.NULL_CONTENT
--                ORDImageExceptions.NULL_DESTINATION

PROCEDURE  applyWatermark (
	imageBfile IN OUT NOCOPY BFILE,
	added_image IN OUT NOCOPY BFILE,
	dest IN OUT NOCOPY BLOB,
	logging OUT VARCHAR2,
	watermark_properties IN ordsys.ord_str_list default null
	);

--  Description: Overlays an image watermark onto a source image stored in a
--  BLOB and writes it to a destination BLOB.
--  Input:
--    imageBlob: The source image data represented as BLOB.
--    added_image: The watermark image stored in a BLOB to be added to the
--    source image.
--    dest: The destination BLOB for the watermarked image.
--    logging: A string that contains information about any unexpected behavior
--    that occurred during the watermarking operation.  If the operation is
--    successful, an empty string is returned.
--    watermark_properties: A string list of name-value pairs that define
--    attributes of the watermark image, including: width, height, position,
--    position_x, position_y, and transparency.
--  Exceptions: ORDImageExceptions.NULL_CONTENT
--            ORDImageExceptions.NULL_DESTINATION

PROCEDURE  applyWatermark (
	imageBlob IN BLOB,
	added_image IN BLOB,
	dest IN OUT NOCOPY  BLOB,
	logging OUT VARCHAR2,
	watermark_properties IN ordsys.ord_str_list   default null
	);

--  Description: Overlays a text watermark onto a source image stored in a BFILE
--  and writes it to a destination BLOB.
--  Input:
--    imageBfile: The source image data represented as BFILE.
--    added_text: The watermark text stored in a string to be added to the source
--    image.
--    dest: The destination BLOB for the watermarked image.
--    logging: A string that contains information about any unexpected behavior
--    that occurred during the watermarking operation.  If the operation is
--    successful,
--    an empty string is returned.  Otherwise, the procedure returns a string
--    that describes the unexpected behavior.  For example, if the watermark
--    text is so long that it is truncated, this string is returned: WARNING:
--    text is too long and truncated.
--    watermark_properties: A string list of name-value pairs that define
--    attributes of the watermark text, including: font_name, font_style,
--    font_size, text_color, position_x, position_y, and transparency.
--  Exceptions: ORDImageExceptions.NULL_CONTENT
--              ORDImageExceptions.NULL_DESTINATION

PROCEDURE  applyWatermark (
	imageBfile IN OUT NOCOPY BFILE,
	added_text IN VARCHAR2,
	dest IN OUT NOCOPY BLOB,
	logging OUT VARCHAR2,
	watermark_properties IN ordsys.ord_str_list default null
	);

--  Description: Overlays a text watermark onto a source image stored in a BLOB
--  and writes it to a destination BLOB.
--  Input:
--  imageBlob: The source image data represented as BLOB.
--  added_text: The watermark text stored in a string to be added to the source
--  image.
--  dest: The destination BLOB for the watermarked image.
--  logging: A string that contains information about any unexpected behavior
--  that occurred during the watermarking operation.  If the operation is
--  successful, an empty string is returned.  Otherwise, the procedure returns a
--  string that describes the unexpected behavior.  For example, if the watermark
--  text is so long that it is truncated, this string is returned: WARNING: text
--  is too long and truncated.
--  watermark_properties: A string list of name-value pairs that define
--  attributes of the watermark text, including: font_name, font_style,
--  font_size, text_color, position_x, position_y, and transparency.
--  Exceptions: ORDImageExceptions.NULL_CONTENT
--              ORDImageExceptions.NULL_DESTINATION

PROCEDURE  applyWatermark (
	imageBlob IN BLOB,
	added_text IN VARCHAR2,
	dest IN OUT NOCOPY BLOB,
	logging OUT VARCHAR2,
	watermark_properties IN ordsys.ord_str_list default null);

--  Description: Extracts the specified types of metadata from the image BFILE
--  and returns an array of schema-valid XML documents.  If no matching metadata
--  is found, an empty array is returned.
--  Input:
--    imageBfile: The image data represented as BFILE.
--    MetadataType: A string that identifies the type of embedded metadata a
--    to extract.
--    Valid values are:  ALL, ORDIMAGE, XMP, EXIF, and IPTC-IIM.  The default
--    value is ALL.
--  Exceptions: ORDImageExceptions.NULL_CONTENT

FUNCTION  getMetadata (
	imageBfile IN BFILE,
	metadataType IN VARCHAR2 DEFAULT 'ALL'
	) RETURN SYS.XMLSequenceType;

--  Description: Extracts the specified types of metadata from the image BLOB and
--  returns an array of schema-valid XML documents.  If no matching metadata is
--  found, an empty array is returned.
--  Input:
--    imageBlob: The image data represented as BLOB.
--    MetadataType: A string that identifies the type of embedded metadata to
--    extract.
--    Valid values are:  ALL, ORDIMAGE, XMP, EXIF, and IPTC-IIM.  The default
--    value is ALL.
--  Exceptions: ORDImageExceptions.NULL_CONTENT

FUNCTION  getMetadata (
	imageBlob IN BLOB,
	metadataType IN VARCHAR2 DEFAULT 'ALL'
	) RETURN SYS.XMLSequenceType;

--  Description: Reads the image BFILE data to get the values of the media
--  attributes for supported formats and then stores them in the input CLOB.
--  This procedure populates the CLOB with a set of format and application
--  properties in XML form.
--  Input:
--    imageBfile: The image data represented as BFILE.
--    attributes: The CLOB to hold the XML attribute information extracted by
--    the getProperties procedure.  This CLOB is populated with a set of
--    format and application properties of the image BFILE data in XML form.
--  Exceptions: ORDImageExceptions.NULL_CONTENT

PROCEDURE  getProperties (
	imageBfile IN OUT NOCOPY BFILE,
	attributes IN OUT NOCOPY CLOB
	);

-- Description: Reads the image BFILE data to get the values of the media
-- attributes for supported formats and
-- returns them as explicit parameters.  This procedure gets the properties for
-- these attributes of the image data: MIME types, width, height, file format,
-- content format, compression format, and content length.
-- Input:
--   imageBfile: The image data represented as BFILE.
--   mimeType: The MIME type of the image data.
--   width: The width of the image in pixels.
--   height: The height of the image in pixels.
--   fileFormat: The format of the image data.
--   contentFormat: The type of image (monochrome, and so on).
--   compressionFormat: The compression algorithm used on the image data.
--   contentLength: The size of the image file on disk, in bytes.
--   Exceptions: ORDImageExceptions.NULL_CONTENT

PROCEDURE  getProperties (
	imageBfile IN OUT NOCOPY BFILE,
	mimeType OUT VARCHAR2,
	width OUT INTEGER,
	height OUT INTEGER,
	fileFormat  out VARCHAR2,
	contentFormat OUT VARCHAR2,
	compressionFormat OUT VARCHAR2,
	contentLength OUT INTEGER
	);

-- Description: Reads the image BLOB data to get the values of the media
-- attributes for supported formats and then stores them in the input CLOB.
-- This procedure populates the CLOB with a set of format and application
-- properties in XML form.
-- Input:
--   imageBlob: The image data represented as BLOB.
--   attributes: The CLOB to hold the XML attribute information extracted by the
--   getProperties procedure.  This CLOB is populated with a set of format and
--   application properties of the image BLOB data in XML form.
-- Exceptions: ORDImageExceptions.NULL_CONTENT

PROCEDURE  getProperties (
	imageBlob IN BLOB,
	attributes IN OUT NOCOPY CLOB
	);

-- Description: Reads the image BLOB data to get the values of the media
-- attributes for supported formats and
-- returns them as explicit parameters.  This procedure gets
-- the properties for these attributes of
-- the image data: MIME types, width, height, file format, content format,
-- compression format, and content length.
-- Input:
--   imageBlob: The image data represented as BLOB.
--   mimeType: The MIME type of the image data.
--   width: The width of the image in pixels.
--   height: The height of the image in pixels.
--   fileFormat: The format of the image data.
--   contentFormat: The type of image (monochrome, and so on).
--   compressionFormat: The compression algorithm used on the image data.
--   contentLength: The size of the image file on disk, in bytes.
-- Exceptions: ORDImageExceptions.NULL_CONTENT

PROCEDURE  getProperties (
	imageBlob IN BLOB,
	mimeType OUT VARCHAR2,
	width OUT INTEGER,
	height OUT INTEGER,
	fileFormat OUT VARCHAR2,
	contentFormat OUT VARCHAR2,
	compressionFormat OUT VARCHAR2,
	contentLength OUT INTEGER
	);

--Description: Transcodes a BLOB, writing the image back onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--  fileFormat: The file format of the resulting image.
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL


PROCEDURE convert (
	imageBlob IN OUT NOCOPY BLOB,
	fileFormat IN VARCHAR2
	);

--Description: Creates a derivative image from a source image stored in a BFILE
--by transcoding the source image and writing the resulting
--image into the destination BLOB.  The original source image is not modified.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  fileFormat: The file format of the resulting image.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.NULL_LOCAL_DATA

PROCEDURE  convert (
	imageBfile IN OUT NOCOPY BFILE,
	fileFormat IN VARCHAR2,
	dest IN OUT NOCOPY BLOB
	);

--Description: Creates a derivative image from a source image stored in a BLOB
--by transcoding the source image and writing the resulting
--image into the destination BLOB.
--The original source image is not modified.
--Input:
--  imageBlob: The source image data represented as BLOB.
--  fileFormat: The file format of the resulting image.
--  dest: The destination of the new image.

PROCEDURE  convert (
	imageBlob IN BLOB,
	fileFormat IN  VARCHAR2,
	dest IN  OUT  NOCOPY  BLOB);

--Description: Define a window to crop from the image in imageBlob, writing the
--image back onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--  originX: Origin X coordinate pixel value.  First pixel value is 0 (zero).
--  originY: Origin Y coordinate pixel value.   First pixel value is 0 (zero).
--  width: Width of cut image in pixels.
--  height: Height of cut image in pixels.
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE  crop (
	imageBlob IN OUT NOCOPY BLOB,
	originX IN INTEGER,
	originY IN INTEGER,
	width IN INTEGER,
	height IN INTEGER
	);

--Description: Creates a derivative image from a source image stored in a BFILE
--by cropping the source image and writing the resulting image into the
--destination BLOB.
--The original source image is not modified.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  originX: Origin X coordinate pixel value.  First pixel value is 0 (zero).
--  originY: Origin Y coordinate pixel value.   First pixel value is 0 (zero).
--  width: Width of cut image in pixels.
--  height: Height of cut image in pixels.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE crop (
	imageBfile IN OUT NOCOPY BFILE,
	originX IN INTEGER,
	originY IN INTEGER,
	width IN INTEGER,
	height IN INTEGER,
	dest IN OUT NOCOPY BLOB
	);

--Description: Creates a derivative image from a source image stored in a BLOB by
--cropping the source image and writing the resulting image into the destination
--BLOB. The original source image is not modified.
--Input:
--  imageBlob: The source image data represented as BLOB.
--  originX: Origin X coordinate pixel value.  First pixel value is 0 (zero).
--  originY: Origin Y coordinate pixel value.   First pixel value is 0 (zero).
--  width: Width of cut image in pixels.
--  height: Height of cut image in pixels.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE crop (
	imageBlob IN BLOB,
	originX IN INTEGER,
	originY IN INTEGER,
	width IN INTEGER,
	height IN INTEGER,
	dest IN OUT NOCOPY BLOB
	);

--Description: Places the scanlines of an image in inverse order, swapped top to
--bottom, writing the image back onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--  Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE  flip (
	imageBlob IN OUT NOCOPY BLOB
	);

--Description: Places the scanlines of an image in inverse order, swapped top to
--bottom,and writes the resulting image into the destination BLOB.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE flip (
	imageBfile IN OUT NOCOPY BFILE,
	dest IN OUT NOCOPY BLOB
	);

--Description: Places the scanlines of an image in inverse order, swapped top to
--bottom, and writes the resulting image into the destination BLOB
--Input:
--  imageBlob: The source image data represented as BLOB.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE flip (
	imageBlob IN BLOB,
	dest IN OUT NOCOPY BLOB
	);

--Description: Converts an image to an 8-bit grayscale image, writing the image
--back onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--  Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE grayscale (
	imageBlob IN OUT NOCOPY BLOB
	);

--Description: Converts an image to an 8-bit grayscale image, and writes the
--resulting image into the destination BLOB.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE  grayscale (
	imageBfile IN OUT NOCOPY BFILE,
	dest IN OUT NOCOPY BLOB
	);

--Description: Converts an image to an 8-bit grayscale image, and writes the
--resulting image into the destination BLOB
--Input:
--  imageBlob: The source image data represented as BLOB.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE grayscale (
	imageBlob IN BLOB,
	dest IN OUT NOCOPY BLOB
	);

--Description: Places the columns of in image in reverse order, swapped left to
--right, writing the image back onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE mirror (
	imageBlob IN OUT NOCOPY BLOB
	);

--Description: Places the columns of in image in reverse order, swapped left to
--right,and writes the resulting image into the destination BLOB.  The original
--source image is not modified.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE mirror(
	imageBfile IN OUT NOCOPY BFILE,
	dest IN OUT NOCOPY BLOB
	);

--Description: Places the columns of in image in reverse order, swapped left to
--right,and writes the resulting image into the destination BLOB.  The original
--source image of is not modified.
--Input:
--  imageBlob: The source image data represented as BLOB.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE  mirror (
	imageBlob IN BLOB,
	dest IN OUT NOCOPY BLOB
	);

--Description: Selects a page from a multipage file, writing the image back onto
--itself.
--This method is for use with TIFF images only.  Page 0 is the first page.
--Input:
--  imageBlob: The image data represented as BLOB.
--  pageNumber: A nonnegative integer representing the page number to be selected.
--  0(zero) represents the first page.
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE  page (
	imageBlob IN OUT NOCOPY BLOB,
	pageNumber IN INTEGER
	);

--Description: Selects a page from a multipage file, and writes the resulting
--image into the destination BLOB.  The original source image is not modified.
--This method is for use with TIFF images only.  Page 0 is the first page.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  pageNumber: A nonnegative integer representing the page number to be
--  selcted.
--  0(zero) represents the first page.
--dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE page(
	imageBfile IN OUT NOCOPY BFILE,
	pageNumber IN INTEGER,
	dest IN OUT NOCOPY BLOB
	);

--Description: Selects a page from a multipage file, and writes the resulting
--image into the destination BLOB.  The original source image is not modified.
--This method is for use with TIFF images only.  Page 0 is the first page.
--Input:
--  imageBlob: The source image data represented as BLOB.
--  pageNumber: A nonnegative integer representing the page number to be
--  selected. 0(zero) represents the first page.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE page(
	imageBlob IN BLOB,
	pageNumber IN INTEGER,
	dest IN OUT NOCOPY BLOB
	);

--Description: Performs one or more image processing operations on a BLOB,
--writing the image back onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--  command: A list of image processing operations to perform on the image.
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE process(
	imageBlob IN OUT NOCOPY BLOB,
	command IN VARCHAR2
	);


-- Description: Creates a derivative image from a source image stored in a BFILE
-- by performing one or more image processing operations on the source image and
-- writing the resulting image into the destination BLOB.  The original source
-- image is not modified.
-- Input:
--   imageBfile: The source image data represented as BFILE.
--   command: A list of image processing operations to perform on the image in
--   order to create a new derivative image to be stored in the dest BLOB.
--   dest: The destination of the new image.
-- Exceptions: ORDImageExceptions.NULL_DESTINATION
--             ORDImageExceptions.NULL_LOCAL_DATA

PROCEDURE  processCopy (
	imageBfile IN OUT NOCOPY BFILE,
	command IN VARCHAR2,
	dest IN OUT NOCOPY BLOB
	);

-- Description: Creates a derivative image from a source image stored in a BLOB
-- by performing one or more image processing operations on the source image and
-- writing the resulting image into the destination BLOB.  The original source
-- image is not modified.
-- Input:
--   imageBlob: The source image data represented as BLOB.
--   command: A list of image processing operations to perform on the image in
--   order to create a new derivative image to be stored in the dest BLOB.
-- dest: The destination of the new image.
-- Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE  processCopy (
	imageBlob IN BLOB,
	command IN VARCHAR2,
	dest IN OUT NOCOPY BLOB
	);

-- Description: Accepts a BFILE containing an image and a schema-valid XML
-- document, and creates a binary packet suitable for embedding in the target
-- image file format.
-- The packet is encoded according to the value of the encoding parameter.
-- If the value of the metadataType parameter is XMP, this procedure writes
-- a new XMP packet to the image, replacing any existing XMP packets.  The new
-- image file with embedded metadata is returned in the dest parameter.  The
-- original image is not changed.
-- Input:
--   imageBfile: The source image data represented as BFILE.
--   dest: The BLOB to receive the image containing the embedded metadata.
--   xmlData: The XMLtype that contains a schema-valid XML document for the
--   indicated metadataType.  If the value of the metadataType parameter is
--   XMP, the root element should contain a well-formed RDF document.
--   metadataType: A string that specifies the type of metadata to write.
--   The valid value is XMP; it is also the default.
--   encoding: The character encoding to be used in the image file.  Valid
--   values are: UTF-8, UTF-16, UTF-16BE, and UTF-16LE.  The default is UTF-8.
-- Exceptions: ORDImageExceptions.NULL_CONTENT
--             ORDImageExceptions.NULL_DESTINATION

PROCEDURE  putMetadata (
	imageBfile IN BFILE,
	dest IN OUT NOCOPY BLOB,
	xmlData IN SYS.XMLType,
	metadataType IN VARCHAR2 DEFAULT 'XMP',
	encoding IN VARCHAR2 DEFAULT 'UTF-8'
	);

-- Description: Accepts a BLOB containing an image and a schema-valid XML
-- document, and creates a binary packet suitable for embedding in the target
-- image file format.
-- The packet is encoded according to the value of the encoding parameter.
-- If the value of the metadataType parameter is XMP, this procedure writes a
-- new XMP packet to the image, replacing any existing XMP packets.  The new
-- image file with embedded  metadata is returned in the dest parameter.  The
-- original image is not changed.
-- Input:
--   ImageBlob: The source image data represented as BLOB.
--   dest: The BLOB to receive the image containing the embedded metadata.
--   xmlData: The XMLtype that contains a schema-valid XML document for the
--   indicated metadataType.  If the value of the metadataType parameter is XMP,
--   the root element should contain a well-formed RDF document.
--   metadataType: A string that specifies the type of metadata to write.  The
--   valid value is XMP; it is also the default.
--   encoding: The character encoding to be used in the image file.  Valid values
--   are: UTF-8, UTF-16, UTF-16BE, and UTF-16LE.  The default is UTF-8.
-- Exceptions: ORDImageExceptions.NULL_CONTENT
--             ORDImageExceptions.NULL_DESTINATION

PROCEDURE  putMetadata (
	imageBlob IN BLOB,
	dest IN OUT NOCOPY BLOB,
	xmlData IN SYS.XMLType,
	metadataType IN VARCHAR2 DEFAULT 'XMP',
	encoding IN VARCHAR2 DEFAULT 'UTF-8'
	);

--Description: Rotates an image within the image plane by the angle specified,
--writing the image back onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--  angle: The angle within the image plane by which to rotate the image.
--  A positive value specifies a clockwise rotation.  A negative value specifies
--  a counter-clockwise rotation.
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE rotate(
	imageBlob IN OUT NOCOPY BLOB,
	angle IN FLOAT
	);

--Description: Rotates an image within the image plane by the angle specified,
--and writes the resulting image into the destination BLOB.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  angle: The angle within the image plane by which to rotate the image.
--  A positive value specifies a clockwise rotation.  A negative value specifies
--  a counter-clockwise rotation.
--dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE rotate(
	imageBfile IN OUT NOCOPY BFILE,
	angle IN FLOAT,
	dest IN OUT NOCOPY BLOB
	);

--Description: Rotates an image within the image plane by the angle specified
--,and writes the resulting image into the destination BLOB
--Input:
--  imageBlob: The source image data represented as BLOB.
--  angle: The angle within the image plane by which to rotate the image.
--  A positive value specifies a clockwise rotation.  A negative value specifies
--  a counter-clockwise rotation.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE rotate(
	imageBlob IN BLOB,
	angle IN FLOAT,
	dest IN OUT NOCOPY BLOB
	);

--Description: Scales the image in imageBlob to a specified size in pixels
--(width, height) while maintaining the aspect ratio, and writes the image back
--onto itself.
--Input:
--  imageBlob: The image data represented as BLOB.
--  width: The maximum width of the image thumbnail in pixels (maintaining
--  aspect ratio).
--  height: The maximum height of the image thunbnail in pixels (maintaining
--  aspect ratio).
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE scale(
	imageBlob IN OUT NOCOPY BLOB,
	width IN INTEGER,
	height IN INTEGER
	);

--Description: Scales the image in imageBfile to a specified size in pixels
--(width, height) while maintaining the aspect ratio, and writes the resulting
--image into the destination BLOB.  The original source image is not modified.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  width: The maximum width of the image thumbnail in pixels
--  (maintaining aspect ratio).
--  height: The maximum height of the image thunbnail in pixels
--  (maintaining aspect ratio).
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE scale(
	imageBfile IN OUT NOCOPY BFILE,
	width IN INTEGER,
	height IN INTEGER,
	dest IN OUT NOCOPY BLOB
	);

--Description: Scales the image in imageBlob to a specified size in pixels
--(width, height) while maintaining the aspect ratio, and writes the resulting
--image into the destination BLOB.  The original source image is not modified.
--Input:
--  imageBlob: The source image data represented as BLOB.
--  width: The maximum width of the image thumbnail in pixels (maintaining
--  aspect ratio).
--  height: The maximum height of the image thunbnail in pixels (maintaining
--  aspect ratio).
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE scale(
	imageBlob IN BLOB,
	width IN INTEGER,
	height IN INTEGER,
	dest IN OUT NOCOPY BLOB
	);

--Description: Scales the image in imageBlob by the given scale factor, writing
--the image back onto itself.  Aspect ratio is maintained.
--Input:
--  imageBlob: The image data represented as BLOB.
--  scaleFactor: The factor by which to scale the image.  A positive FLOAT value.
--Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE scale(
	imageBlob IN OUT NOCOPY BLOB,
	scaleFactor IN FLOAT
	);

--Description: Scales the image in imageBlob by the given scale factor, and
--writes the resulting image into the destination BLOB.  The original source
--image is not modified. Aspect ratio is maintained,
--Input:
--  imageBfile: The source image data represented as BFILE.
--  scaleFactor: The factor by which to scale the image.  A positive FLOAT value.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION

PROCEDURE scale(
	imageBfile IN OUT NOCOPY BFILE,
	scaleFactor IN FLOAT,
	dest IN OUT NOCOPY BLOB
	);

--Description: Scales the image in imageBlob by the given scale factor, and
--writes the resulting image into the destination BLOB.  Aspect ratio is
--maintained.
--The original source image is not modified.
--Input:
--  imageBlob: The source image data represented as BLOB.
--  scaleFactor: The factor by which to scale the image.  A positive FLOAT value.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE scale(
	imageBlob IN BLOB,
	scaleFactor IN INTEGER,
	dest IN OUT NOCOPY BLOB
	);

--Description: Creates an 80x80 pixel thumbnail image from the image in
--imageBlob, writing the image back onto itself.  Aspect ratio is maintained.
--Input:
--  imageBlob: The image data represented as BLOB.
--  Exceptions: ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE thumbnail(
	imageBlob IN OUT NOCOPY BLOB
	);

--Description: Creates a derivative image from a source image stored in a BFILE
--by creating an 80x80 thumbnail image and writing the resulting image into the
--destination BLOB.  Aspect ratio is maintained.  The original source image is
--not modified.
--Input:
--  imageBfile: The source image data represented as BFILE.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION


PROCEDURE thumbnail(
	imageBfile IN OUT NOCOPY BFILE,
	dest IN OUT NOCOPY BLOB
	);

--Description: Creates a derivative image from a source image stored in a BLOB
--by creating an 80x80 thumbnail image and writing the resulting image into the
--destination BLOB.
--Aspect ratio is maintained.  The original source image is not modified.
--Input:
--  imageBlob: The source image data represented as BLOB.
--  dest: The destination of the new image.
--Exceptions: ORDImageExceptions.NULL_DESTINATION
--            ORDImageExceptions.DATA_NOT_LOCAL

PROCEDURE thumbnail(
	imageBlob IN BLOB,
	dest IN OUT NOCOPY BLOB
	);
END;
/

