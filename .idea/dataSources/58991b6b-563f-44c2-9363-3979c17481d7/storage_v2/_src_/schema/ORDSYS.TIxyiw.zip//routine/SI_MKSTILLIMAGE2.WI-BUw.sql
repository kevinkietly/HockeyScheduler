create FUNCTION
  SI_mkStillImage2 wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
f4 f3
CDDhLhk5XDOYkISSqOeSxYSkNKIwgwFKfyisfC8CkDqUpGw44AHFQ6ltzT1xZPxgdl9/FYu1
0DuvBIHwlg8Z/pJaYFC3nldi/qVT14LRwR5jGauu4RQnsvEnOyDVXE213d4gsw7SQZCnRxwh
E8zHTBtuNWaddDVQo/UjqcMeFu+fl6KLXVjgptx5W+GKyHwtYDgWowTIwvWQqFc/ru1PKyR4
l+im/GUenyxFSN+u8SAiUg==
/

