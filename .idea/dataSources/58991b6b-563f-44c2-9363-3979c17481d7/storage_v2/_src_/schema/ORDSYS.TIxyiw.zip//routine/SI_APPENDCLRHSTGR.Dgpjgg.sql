create PROCEDURE
  SI_appendClrHstgr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
147 124
BvyGA4ERHyv10+7sUT7//HsFVjIwg3lKf8sVfHTpWBKe0MPmcQ5eoVXUCUvWt3RZ573brGlE
aA8UY92snFf5tTGaCgSK8WY2e3bGCM/aWB5VIkGc+MLG329EqQQU6XB/Bv6V3tv0o57MOXnE
Cp75d11YRV+qdbU8h1KcyNe8VNqh/QePlLJE0+KCJegRJh23w/eGqER3emNpebjK0domByBw
nt36vqtR6UEoxcn0EykH0Y96Qfcy/7Ej0Ghimn+q9/z0+vIis8NDcyPwXv0GDtcGRD+I3Hc=

/

