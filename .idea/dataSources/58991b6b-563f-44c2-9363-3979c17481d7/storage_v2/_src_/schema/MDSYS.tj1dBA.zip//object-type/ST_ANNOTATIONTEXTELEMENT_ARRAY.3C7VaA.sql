create TYPE ST_ANNOTATIONTEXTELEMENT_ARRAY
                                                                              
    AS OBJECT (
     privateArray  ST_ANNOT_TEXTELEMENT_ARRAY ,
    MEMBER FUNCTION ElementN ( aposition INTEGER)
          RETURN ST_ANNOTATIONTEXTELEMENT,
    MEMBER FUNCTION ElementN ( element ST_ANNOTATIONTEXTELEMENT, aposition INTEGER)  RETURN ST_ANNOTATIONTEXTELEMENT_ARRAY )
/

