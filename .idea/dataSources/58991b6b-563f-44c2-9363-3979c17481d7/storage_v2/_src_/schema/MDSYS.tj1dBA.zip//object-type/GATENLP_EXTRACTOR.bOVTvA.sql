create type gatenlp_extractor under mdsys.rdfctx_extractor (

      gate_host  VARCHAR2(100),
      gate_port  NUMBER,
      xsl_trans  sys.XMLtype,

      constructor function gatenlp_extractor (base_url  VARCHAR2 default null)
                        return self as result,

      constructor function gatenlp_extractor (xsl_trans  sys.xmltype)
                        return self as result,

      overriding member function getDescription return VARCHAR2,

      overriding member function extractRdf (document CLOB,
                                             docId    VARCHAR2) return CLOB

    )
/

