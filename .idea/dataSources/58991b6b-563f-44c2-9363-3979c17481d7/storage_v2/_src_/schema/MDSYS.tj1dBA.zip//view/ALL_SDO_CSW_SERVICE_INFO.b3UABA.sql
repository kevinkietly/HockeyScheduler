create view ALL_SDO_CSW_SERVICE_INFO as
SELECT b.SDO_OWNER       OWNER,
       b.CSW_VERSION     CSW_VERSION,
       b.CSW_XSD_ID      XSD_ID,
       b.CSW_TABLE_NAME  TABLE_NAME
FROM MDSYS.CSW_SERVICE_INFO b,
     SYS.all_objects a
WHERE  b.CSW_TABLE_NAME =  a.object_name
  AND  b.SDO_OWNER      =  a.owner
  AND  a.object_type    in ('TABLE', 'SYNONYM', 'VIEW')
/

