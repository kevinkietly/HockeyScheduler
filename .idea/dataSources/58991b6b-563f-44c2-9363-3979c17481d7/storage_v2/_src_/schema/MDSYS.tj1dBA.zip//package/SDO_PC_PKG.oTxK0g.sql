create PACKAGE       sdo_pc_pkg authid current_user AS
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -- all tables as "schema.table" for simpler interface.
  FUNCTION INIT(
    basetable          varchar2,
    basecol            varchar2,
    blktable           VARCHAR2,
    ptn_params         varchar2,
    pc_extent          mdsys.sdo_geometry     default null,
    pc_tol             NUMBER           default 0.0000000000005,
    pc_tot_dimensions  NUMBER           default 2,
    pc_domain          mdsys.sdo_orgscl_type  default null,
    pc_val_attr_tables mdsys.SDO_STRING_ARRAY default null,
    pc_other_attrs     SYS.XMLTYPE      default null)
      RETURN mdsys.SDO_PC;

  procedure create_liblas_pyramid(
    pc               in mdsys.sdo_pc,
    keepLevel1Intact in number);

  PROCEDURE CREATE_PC(
    inp              mdsys.sdo_pc,
    inptable         varchar2,
          clstpcdatatbl    varchar2 default null);

  PROCEDURE ADD_TO_PC(
    inp      mdsys.sdo_pc,
    inptable varchar2);

  FUNCTION HAS_PYRAMID(
    inp mdsys.sdo_pc)
      return number;

  FUNCTION PRESERVES_LEVEL1(
    inp mdsys.sdo_pc)
      return number;

  -- works as read if qry params are null
  FUNCTION CLIP_PC(
    inp                 mdsys.sdo_pc,
    ind_dim_qry         mdsys.sdo_geometry,
    other_dim_qry       mdsys.sdo_mbr,
    qry_min_res         number,
    qry_max_res         number,
    blkno               number default null,
    include_custom_dims number default 0)
      RETURN MDSYS.SDO_PC_BLK_TYPE PIPELINED;

  PROCEDURE DROP_DEPENDENCIES(basetable varchar2, col varchar2);

  FUNCTION TO_GEOMETRY(pts BLOB, num_pts NUMBER,
                       pc_tot_dim NUMBER, srid NUMBER default null,
                       blk_domain mdsys.sdo_orgscl_type default null,
                       get_ids  NUMBER default NULL)
    RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION GET_PT_IDs(pts BLOB, num_pts NUMBER,
                      pc_tot_dim NUMBER,
                      blk_domain mdsys.sdo_orgscl_type default null)
    RETURN MDSYS.SDO_NUMBER_ARRAY DETERMINISTIC;

  function tin_to_pc(
    tin       MDSYS.sdo_tin,
    basetable varchar2,
    basecol   varchar2,
    blktable  varchar2)
      return MDSYS.sdo_pc deterministic;

/*
PROCEDURE POPULATE_FROM_CLSTPCDATA(inp MDSYS.sdo_pc, clstpcdatatbl varchar2);

  PROCEDURE WRITE_CLSTPCDATA(inp MDSYS.sdo_pc, clstpcdatatbl varchar2);
*/


/*
  -- works as read if qry is null
  FUNCTION CLIP_PCAttrs(inp MDSYS.sdo_pc, qry MDSYS.sdo_geometry, blkno number default null)
    RETURN ANYDATASET;
  FUNCTION CLIP_PC_PtIds(inp MDSYS.sdo_pc, qry MDSYS.sdo_geometry, blkno number default null)
    RETURN ANYDATASET;
*/

  function clip_pc_into_tin(
    pc_inp            MDSYS.sdo_pc,
    pc_ind_dim_qry    MDSYS.sdo_geometry,
    pc_other_dim_qry  MDSYS.sdo_mbr,
    pc_qry_min_res    number,
    pc_qry_max_res    number,
    tin_basetable     varchar2,
    tin_basecol       varchar2,
    tin_blktable      varchar2,
    tin_ptn_params    varchar2     default null,
    tin_break_lines   MDSYS.sdo_geometry default null,
    tin_stop_lines    MDSYS.sdo_geometry default null,
    tin_void_rgns     MDSYS.sdo_geometry default null,
    tin_clstpcdatatbl varchar2     default null,
    pc_blkno          number       default null)
      return mdsys.sdo_tin;

  function create_contour_geometries(
    pc                  MDSYS.sdo_pc,
    sampling_resolution number,
    elevations          MDSYS.sdo_ordinate_array,
    region              MDSYS.sdo_geometry)
      return MDSYS.sdo_geometry_array;

  function create_contour_geometries(
    pc_flat_table       varchar2,
    srid                number,
    sampling_resolution number,
    elevations          MDSYS.sdo_ordinate_array,
    region              MDSYS.sdo_geometry)
      return MDSYS.sdo_geometry_array;

  function create_contour_geometries(
    pc                  MDSYS.sdo_pc,
    sampling_resolution number,
    elevations_min      number,
    elevations_interval number,
    elevations_max      number,
    region              MDSYS.sdo_geometry)
      return MDSYS.sdo_geometry_array;

  function create_contour_geometries(
    pc_flat_table       varchar2,
    srid                number,
    sampling_resolution number,
    elevations_min      number,
    elevations_interval number,
    elevations_max      number,
    region              MDSYS.sdo_geometry)
      return MDSYS.sdo_geometry_array;

  /* This procedure takes a 2D Geometry as input and generates
     two SQL strings which can be appended to a user cursor in the
     where clause. */
  PROCEDURE get_tile_sql (
    geometry     IN  MDSYS.SDO_GEOMETRY,
    sql_interior OUT VARCHAR2,
    sql_boundary OUT VARCHAR2,
    tolerance    IN  NUMBER DEFAULT 0.0000005,
    sdo_level    in  NUMBER DEFAULT 2,
    sdo_ntiles   in  NUMBER DEFAULT 100);

  /* This function returns a REFCURSOR which can be queried by the client
     side code to fetch rows from the base table. The columns are the columns
     of the base table: only numberic and VARCHAR columns allowed.
     Query Geometry is used to clip the points from the base table.
     First two colums should be X and Y. SRID is assumed to be the same
     as the one used in Geometry.  */
  FUNCTION clip_pc_flat (geometry IN MDSYS.SDO_GEOMETRY,
                         table_name IN VARCHAR2,
                         tolerance IN NUMBER,
                         other_dim_qry  IN MDSYS.SDO_MBR DEFAULT NULL,
                         mask IN VARCHAR2 DEFAULT 'ANYINTERACT')

  RETURN SYS_REFCURSOR;

  /* Same as the above, but return the actual SQL statement instead of the
     cursor. Users can add additional predicates or select list and
     execute it. */
  FUNCTION clip_pc_flat_string (geometry IN MDSYS.SDO_GEOMETRY,
                                table_name IN VARCHAR2,
                                tolerance IN NUMBER,
                                other_dim_qry  IN MDSYS.SDO_MBR DEFAULT NULL,
                                mask IN VARCHAR2 DEFAULT 'ANYINTERACT',
                                dop IN INTEGER DEFAULT NULL,
                                sdo_level in number DEFAULT 4,
                                sdo_ntiles in number DEFAULT 100)
  RETURN clob;

  procedure import_las(
    source_las_directory_obj_name varchar2,
    source_las_file               varchar2,
    source_las_file_id            varchar2,
    target_table                  varchar2,
    add_columns                   number);

  function hilbert_xy2d(
    n number,
    x number,
    y number)
      return number DETERMINISTIC PARALLEL_ENABLE;

  function get_blocking_method(
    inp MDSYS.sdo_pc)
      return varchar2;

  function getNthHilbertValue(
    table_name varchar2,
    n          number)
      return number;

  function merge_cells(
    cell_mbrs MDSYS.sdo_ordinate_array)
      return MDSYS.sdo_ordinate_array;

  function sort_block_by_dist(
    num_points number,
    points     blob,
    center     MDSYS.sdo_geometry)
      return blob;

  function sdo_pc_nn(
    pc     MDSYS.sdo_pc,
    center MDSYS.sdo_geometry,
    n      number)
      return blob;

  PROCEDURE CLIP_PC_get_min_height(
    inp           in  MDSYS.sdo_pc,
    ind_dim_qry   in  MDSYS.sdo_geometry,
    other_dim_qry in  MDSYS.sdo_mbr,
    qry_min_res   in  number,
    qry_max_res   in  number,
    blkno         in  number default null,
    min_height    out number,
    max_height    out number,
    avg_height    out number,
    median_height out number);

  procedure hilbert_blocking(
    obj_id            number,
    srid              number,
    input_table_name  varchar2,
    block_table_name  varchar2,
    block_size        number,
    pc_tol            NUMBER default 0.0000000000005,
    pc_tot_dimensions NUMBER default 3);

  TYPE simple_blk_ref IS RECORD (
    blk_id        number,
    ind_dim_qry   MDSYS.sdo_geometry,
    other_dim_qry MDSYS.sdo_mbr);

  TYPE simple_block_ref_cursor IS REF CURSOR RETURN simple_blk_ref;

  TYPE sdo_id_and_xy IS RECORD (
    id rowid,
    x  number,
    y  number);

  TYPE sdo_id_and_xy_cursor IS REF CURSOR RETURN sdo_id_and_xy;

  TYPE sdo_id_and_hilbert is record (
    rid     varchar2(24),
    hilbert number);

  TYPE sdo_id_and_hilbert_tab is TABLE OF sdo_id_and_hilbert;

  TYPE sdo_id_and_hilbert_cursor IS REF CURSOR RETURN sdo_id_and_hilbert;

  TYPE sdo_id_and_hbp is record (
    rid     varchar2(24),
    hilbert number,
    blk_id  number,
    pt_id   number,
    p       number);

  TYPE sdo_id_and_hbp_tab is TABLE OF sdo_id_and_hbp;

  TYPE simple_block_record IS RECORD (
    points     blob,
    num_points number);

  TYPE simple_block_record_cursor IS REF CURSOR RETURN simple_block_record;

  TYPE simple_pt_row IS RECORD (
    obj_id  number,
    blk_id  number,
    pt_id   number,
    val_d1  number,
    val_d2  number,
    val_d3  number,
    val_d4  number,
    val_d5  number,
    val_d6  number,
    val_d7  number,
    val_d8  number,
    val_d9  number,
    val_d10 number,
    val_d11 number,
    val_d12 number);

  type point_neighbor_pair_row is record (
    obj_id          number,
    blk_id          number,
    pt_id           number,
    pt_x            number,
    pt_y            number,
    pt_z            number,
    neighbor_rank   number,
    neighbor_dist   number,
    neighbor_blk_id number,
    neighbor_pt_id  number,
    neighbor_x      number,
    neighbor_y      number,
    neighbor_z      number);

  TYPE simple_pt_tab IS TABLE OF simple_pt_row;

  type point_neighbor_pair_tab is table of point_neighbor_pair_row;

  type neighbor_type is record (
    pt     MDSYS.sdo_geometry,
    blk_id number,
    pt_id  number);

  type neighbor_tab_type is table of neighbor_type;

  type bd_array is varray(10) of binary_double;
  type bi_array is varray(10) of binary_integer;

  procedure parse_32bit_ints(
    field    in     raw,
    pos0     in     binary_integer,
    interval in     binary_integer,
    vals     in out bi_array);

  procedure parse_64bit_doubles(
    field    in     raw,
    pos0     in     binary_integer,
    interval in     binary_integer,
    vals     in out bd_array);

  procedure parse_32bit_ints(
    field in     raw,
    pos0  in     binary_integer,
    val0     out binary_integer,
    pos1  in     binary_integer,
    val1     out binary_integer,
    pos2  in     binary_integer,
    val2     out binary_integer,
    pos3  in     binary_integer,
    val3     out binary_integer,
    pos4  in     binary_integer,
    val4     out binary_integer,
    pos5  in     binary_integer,
    val5     out binary_integer,
    pos6  in     binary_integer,
    val6     out binary_integer,
    pos7  in     binary_integer,
    val7     out binary_integer,
    pos8  in     binary_integer,
    val8     out binary_integer,
    pos9  in     binary_integer,
    val9     out binary_integer);

  procedure parse_64bit_doubles(
    field in     raw,
    pos0  in     binary_integer,
    val0     out binary_double,
    pos1  in     binary_integer,
    val1     out binary_double,
    pos2  in     binary_integer,
    val2     out binary_double,
    pos3  in     binary_integer,
    val3     out binary_double,
    pos4  in     binary_integer,
    val4     out binary_double,
    pos5  in     binary_integer,
    val5     out binary_double,
    pos6  in     binary_integer,
    val6     out binary_double,
    pos7  in     binary_integer,
    val7     out binary_double,
    pos8  in     binary_integer,
    val8     out binary_double,
    pos9  in     binary_integer,
    val9     out binary_double);

  procedure get_hilbert(
    x0 in  binary_integer,
    y0 in  binary_integer,
    d0 out binary_integer,
    x1 in  binary_integer,
    y1 in  binary_integer,
    d1 out binary_integer,
    x2 in  binary_integer,
    y2 in  binary_integer,
    d2 out binary_integer,
    x3 in  binary_integer,
    y3 in  binary_integer,
    d3 out binary_integer,
    x4 in  binary_integer,
    y4 in  binary_integer,
    d4 out binary_integer,
    x5 in  binary_integer,
    y5 in  binary_integer,
    d5 out binary_integer,
    x6 in  binary_integer,
    y6 in  binary_integer,
    d6 out binary_integer,
    x7 in  binary_integer,
    y7 in  binary_integer,
    d7 out binary_integer,
    x8 in  binary_integer,
    y8 in  binary_integer,
    d8 out binary_integer,
    x9 in  binary_integer,
    y9 in  binary_integer,
    d9 out binary_integer);

  function get_hilbert(
    x0 in  binary_integer,
    y0 in  binary_integer) return binary_integer deterministic;

  function clip_pc_parallel(
    blocks        sdo_pc_pkg.simple_block_ref_cursor,
    inp           MDSYS.sdo_pc)
      return sdo_pc_pkg.simple_pt_tab
        pipelined
        parallel_enable(
          partition blocks by hash (blk_id));

  function generate_hilbert_vals(
    id_xy sdo_id_and_xy_cursor)
      return sdo_id_and_hilbert_tab
        pipelined
        parallel_enable(
          partition id_xy by any);

  function generate_hbp_vals(
    id_hilbert   sdo_id_and_hilbert_cursor,
    blk_capacity number)
      return sdo_id_and_hbp_tab
        pipelined;

  function gen_hybrid_pc_CTAS_script(
    inptab_name      varchar2,
    wrapped_in_block number default 1)
      return varchar2;

  function gen_hybrid_pc_query_script(
    inptab_name  varchar2)
      return varchar2;

  function find_contour2(
    points     BLOB,
    num_points number,
    elevation  number)
      return sdo_ordinate_array;

  function find_contour(
    blocks     sdo_pc_pkg.simple_block_record_cursor,
    hilbert_pc sdo_pc,
    height     number)
      return sdo_pc_pkg.simple_pt_tab
        pipelined
        parallel_enable(
          partition blocks by any);

  function sdo_pc_nn_for_each(
    blocks      sdo_pc_pkg.simple_block_ref_cursor,
    pc          MDSYS.sdo_pc,
    n           number,
    max_dist    number,
    qry_min_res number,
    qry_max_res number)
      return sdo_pc_pkg.point_neighbor_pair_tab
        pipelined
        parallel_enable(
          partition blocks by hash (blk_id));

  function project_ords_onto_pc(
    ordinates2d MDSYS.sdo_ordinate_array,
    mbr         MDSYS.sdo_geometry,
    pc          MDSYS.sdo_pc)
      return MDSYS.sdo_ordinate_array
        deterministic parallel_enable;

  function project_ords_onto_pc(
    ordinates2d  MDSYS.sdo_ordinate_array,
    buffer_width number,
    pc           MDSYS.sdo_pc,
    tol          number)
      return MDSYS.sdo_ordinate_array
        deterministic parallel_enable;

  function project_ords_onto_pc(
    ordinates2d MDSYS.sdo_ordinate_array,
    mbr         MDSYS.sdo_geometry,
    pc_table    varchar2)
      return MDSYS.sdo_ordinate_array
        deterministic parallel_enable;

  function project_ords_onto_pc(
    ordinates2d  MDSYS.sdo_ordinate_array,
    buffer_width number,
    pc_table     varchar2,
    tol          number)
      return MDSYS.sdo_ordinate_array
        deterministic parallel_enable;

  procedure create_pc_hybrid(
    source_table_name     varchar2,
    data_table_name_base  varchar2,
    add_to_existing_table number default 0,
    srid                  number default null);

  procedure create_pc_unified(
    pc_type    varchar2,
    inp_table  varchar2,
    base_table varchar2,
    data_table varchar2,
    pc_id      number,
    pc_tol     number,
    blk_size   number,
    srid       number       default null,
    sfc_domain sdo_geometry default null,
    sfc_type   varchar2     default '2D Hilbert as NUMBER', -- ('2D Hilbert as NUMBER', '2D Hilbert as RAW')
    pc_extent  sdo_geometry default null);

  procedure drop_pc_hybrid(
    data_table_name_base varchar2);

  procedure add_hilbert_to_flat_model_pc(
    source_table_name    varchar2,
    data_table_name_base varchar2);

  procedure clip_pc_into_table(
    pc_table          varchar2,
    pc_column         varchar2,
    id_column         varchar2,
    id                varchar2,
    query             MDSYS.sdo_geometry,
    where_clause      varchar2,
    result_table_name varchar2,
    lods              MDSYS.sdo_lods_type,
    category_table    varchar2 default null,
    category_match    varchar2 default null,
    category_query    varchar2 default null)
      PARALLEL_ENABLE;

  procedure clip_pc_into_table_hybrid(
    data_table_name_base varchar2,
    query                mdsys.sdo_geometry,
    where_clause         varchar2,
    result_table_name    varchar2,
    lods                 mdsys.sdo_lods_type,
    category_table       varchar2 default null,
    category_match       varchar2 default null,
    category_query       varchar2 default null,
    pc_id                number   default null)
      PARALLEL_ENABLE;

  procedure clip_pc_into_las(
    pc_table          in  varchar2,
    pc_column         in  varchar2,
    id_column         in  varchar2,
    id                in  varchar2,
    query             in  mdsys.sdo_geometry,
    where_clause      in  varchar2,
    result_table_name in  varchar2,
    result_las        out blob,
    lods              in  mdsys.sdo_lods_type,
    lasScaleX         in  number,
    lasScaleY         in  number,
    lasScaleZ         in  number,
    lasOffsetX        in  number,
    lasOffsetY        in  number,
    lasOffsetZ        in  number,
    lasMinX           in  number,
    lasMaxX           in  number,
    lasMinY           in  number,
    lasMaxY           in  number,
    lasMinZ           in  number,
    lasMaxZ           in  number);

  procedure clip_pc_into_las(
    pc_table          in  varchar2,
    pc_column         in  varchar2,
    id_column         in  varchar2,
    id                in  varchar2,
    query             in  mdsys.sdo_geometry,
    where_clause      in  varchar2,
    result_table_name in  varchar2,
    result_las        out blob,
    lods              in  mdsys.sdo_lods_type,
    lasScaleX         in  number,
    lasScaleY         in  number,
    lasScaleZ         in  number,
    lasOffsetX        in  number,
    lasOffsetY        in  number,
    lasOffsetZ        in  number);

  procedure clip_pc_into_las(
    pc_table          in  varchar2,
    pc_column         in  varchar2,
    id_column         in  varchar2,
    id                in  varchar2,
    query             in  mdsys.sdo_geometry,
    where_clause      in  varchar2,
    result_table_name in  varchar2,
    result_las        out blob,
    lods              in  mdsys.sdo_lods_type,
    lasScaleX         in  number,
    lasScaleY         in  number,
    lasScaleZ         in  number);

  procedure clip_pc_into_las(
    pc_table          in  varchar2,
    pc_column         in  varchar2,
    id_column         in  varchar2,
    id                in  varchar2,
    query             in  mdsys.sdo_geometry,
    where_clause      in  varchar2,
    result_table_name in  varchar2,
    result_las        out blob,
    lods              in  mdsys.sdo_lods_type);

  function get_pc_model(
    pc mdsys.sdo_pc)
      return varchar2;

  procedure create_contour_geometries(
    pc                  mdsys.sdo_pc,
    sampling_resolution number,
    elevations          mdsys.sdo_number_array,
    region              mdsys.sdo_geometry,
    contour_table       varchar2);

  procedure create_contour_geometries(
    pc                  mdsys.sdo_pc,
    sampling_resolution number,
    elevations_min      number,
    elevations_interval number,
    elevations_max      number,
    region              mdsys.sdo_geometry,
    contour_table       varchar2);

  procedure pc2dem(
    geor              in out mdsys.sdo_georaster,
    pc                in     mdsys.sdo_pc,
    mbr2d             in     mdsys.sdo_geometry,
    resolution        in     number,
    blockSize         in     number);

  procedure pc2dem(
    geor              in out mdsys.sdo_georaster,
    pc                in     mdsys.sdo_pc,
    mbr2d             in     mdsys.sdo_geometry,
    resolutionVert    in     number,
    resolutionHoriz   in     number,
    blockSizeVert     in     number,
    blockSizeHoriz    in     number);

  procedure add_categories_to_pc(
    pc_table        in varchar2,
    pc_column       in varchar2,
    id_column       in varchar2,
    id              in varchar2,
    category_table  in varchar2,
    categories      in sdo_string_array,
    default_value   in varchar2 default null,
    value_generator in varchar2 default null);


  procedure reset_pc_srid(
    pc_table  in varchar2,
    pc_column in varchar2,
    id_column in varchar2,
    id        in varchar2,
    srid      in number);

  procedure transform_pc_srid(
    pc_table       in varchar2,
    pc_column      in varchar2,
    id_column      in varchar2,
    id             in varchar2,
    new_pc_table   in varchar2,
    new_pc_column  in varchar2,
    new_id_column  in varchar2,
    new_id         in varchar2,
    new_srid       in number,
    new_data_table in varchar2);

  procedure update_category_values(
    pc_table          in varchar2,
    pc_column         in varchar2,
    id_column         in varchar2,
    id                in varchar2,
    category_table    in varchar2,
    result_table_name in varchar2);

END sdo_pc_pkg;
/

