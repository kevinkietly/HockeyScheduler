create PACKAGE       sdo_ols_locutl AUTHID current_user AS

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  FUNCTION geocodeSingleAdr(
    addressInRequest  XMLTYPE,
    openLsVersion     VARCHAR2)
      RETURN XMLTYPE;

  FUNCTION makeOpenLS10Request(
    request XMLTYPE)
      RETURN XMLTYPE;

END sdo_ols_locutl;
/

