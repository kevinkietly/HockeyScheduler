create package       SDO_AGGR wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
140 103
yUXOuQDHZaeUP5KNQNT1LpYdhekwg43wf8sVfHTpWMee0OnlU2dJ61OoZlJmxoh7Q/nE3Yhw
OGdf+bv4cxj4th01TgFw5+G0gfMAikxGVIAgkZPH/1yvyPOjZCrM30DeGtNAgJWV6zcAKZ5x
deITx4DBTAvu0DAhZf26oFd1I+M5ct9Gy5ij95R0EaG2uHK/8Qq2JdF0MbpO31w38huNTv7b
mK0ymrUd6aVxtVQ2rvLx78boUsQQ4J1Mh3OaXKU=
/

