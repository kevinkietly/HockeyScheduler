create PACKAGE       SDO_ROUTER_TIMEZONE AUTHID current_user AS
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE cleanup_timezones;
  PROCEDURE create_router_timezones_edges(log_file_name IN VARCHAR2 := 'sdo_router_timezones.log');
  PROCEDURE create_sdo_timezones_index(log_file_name IN VARCHAR2 := 'sdo_router_timezones.log');
END SDO_ROUTER_TIMEZONE;
/

