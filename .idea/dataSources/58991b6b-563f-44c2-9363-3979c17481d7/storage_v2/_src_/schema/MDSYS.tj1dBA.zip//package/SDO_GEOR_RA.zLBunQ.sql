create PACKAGE       SDO_GEOR_RA AUTHID CURRENT_USER AS

--
-- Math Operator constants
--
   OPERATOR_ADD               CONSTANT PLS_INTEGER := 0;
   OPERATOR_ADDCONST          CONSTANT PLS_INTEGER := 1;
   OPERATOR_SUBTRACT          CONSTANT PLS_INTEGER := 2;
   OPERATOR_SUBTRACTCONST     CONSTANT PLS_INTEGER := 3;
   OPERATOR_MULTIPLY          CONSTANT PLS_INTEGER := 4;
   OPERATOR_MULTIPLYCONST     CONSTANT PLS_INTEGER := 5;
   OPERATOR_DIVIDE            CONSTANT PLS_INTEGER := 6;
   OPERATOR_DIVIDECONST       CONSTANT PLS_INTEGER := 7;
   OPERATOR_ABSOLUTE          CONSTANT PLS_INTEGER := 8;
   OPERATOR_INVERT            CONSTANT PLS_INTEGER := 9;
   OPERATOR_LOG               CONSTANT PLS_INTEGER := 10;
   OPERATOR_EXP               CONSTANT PLS_INTEGER := 11;

-- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

-- NAME:
--      stack procedure
--
-- DESCRIPTION
--      Return a single layer raster either in a GeoRaster object or a single BLOB. Each of raster cell values is decided by method parameter,
--      which value is one of the following values:
--                   max/min/median/mean/std/sum
--
--
--
-- ARGUMENTS
--      georArray      - An array of GeoRaster objects.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      layerList      - A number array to specify which band of each input GeoRaster object is used to
--                       compute for output
--      method         - A string to specify the method to compute for output, it must be one of the following values:
--                             max/min/median/mean/std/sum
--      storageParam   - A string specifying storage parameters for the copy
--                       The details are explained in GeoRaster Manual
--      outGeoRaster   - The output GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
-- RETURNS
--
PROCEDURE stack
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   layerList    IN      MDSYS.SDO_NUMBER_ARRAY,
   method       IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE stack
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   layerList    IN      MDSYS.SDO_NUMBER_ARRAY,
   method       IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE stack
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   layerList    IN      MDSYS.SDO_NUMBER_ARRAY,
   method       IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  NOCOPY BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0
);

PROCEDURE stack
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   layerList    IN      MDSYS.SDO_NUMBER_ARRAY,
   method       IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  NOCOPY BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false'
);

--
-- NAME:
--      findCells procedure
--
-- DESCRIPTION
--       generate a new raster either in a georaster object or a single BLOB
--       based on the "condition" parameter.
--       The "condition" parameter is a boolean expression, for each pixel
--       in the inGeoRaster, the value of corresponding pixel of outGeoraster
--       is same, if "condition" is true, otherwise bgValues is used to set
--       the pixel's value of outGeoraster.
--
--
-- ARGUMENTS
--      inGeoRaster    - The SDO_GEORASTER object to be applied with condition
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      condition      - A boolean expression used to filter out pixels, the
--                       syntax details are explained in GeoRaster Manual
--      storageParam   - A string specifying storage parameters for the target
--                       georaster object. The details are explained in GeoRaster
--                       Manual
--      outGeoRaster   - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      bgValues       - background values for filling pixels which make
--                       conditon return false, if it is null, then 0 will
--                       be used as background color.
--      nodata         - if 'true', then keep original value for all nodata pixel
--                       if 'false',then treat nodata as regular data.
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and you can't rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
-- RETURNS
--
PROCEDURE findCells
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   condition    IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN     VARCHAR2 DEFAULT NULL
);

PROCEDURE findCells
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   condition    IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN     VARCHAR2 DEFAULT NULL
);

PROCEDURE findCells
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   condition    IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   polygonClip  IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN     VARCHAR2 DEFAULT NULL
);


PROCEDURE findCells
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   condition    IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false'
);

PROCEDURE findCells
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   condition    IN      VARCHAR2,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   polygonClip  IN      VARCHAR2 DEFAULT 'false'
);


-- NAME:
--      classify procedure
--
-- DESCRIPTION
--      Generate a new raster either in a GeoRaster object or a single BLOB
-- after applying classification operation on the source GeoRaster object.
--
-- ARGUMENTS
--      inGeoRasters   - GeoRaster cursor.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      expression     - A math expression used to classify cell values, the
--                       syntax details are explained in GeoRaster Manual
--      rangeArray     - A number array, which defines ranges to classify cell
--                       values, it must have at least one element.
--      valueArray     - A number array, which defines target cell value for
--                       each range. it's length must be "length of rangeArray"+1
--      storageParam   - A string specifying storage parameters for the copy
--                       The details are explained in GeoRaster Manual
--      outGeoRaster   - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
-- RETURNS
--
PROCEDURE classify
(
   inGeoRasters IN      SYS_REFCURSOR,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam   IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE classify
(
   inGeoRasters IN      SYS_REFCURSOR,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam   IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE classify
(
   inGeoRasters IN      SYS_REFCURSOR,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN     VARCHAR2 DEFAULT NULL
);

PROCEDURE classify
(
   inGeoRasters IN      SYS_REFCURSOR,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0
);

PROCEDURE classify
(
   inGeoRasters IN      SYS_REFCURSOR,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false'
);

-- NAME:
--      classify procedure
--
-- DESCRIPTION
--      Generate a new raster either in a GeoRaster object or a single BLOB
-- after applying classification operation on the source GeoRaster object.
--
-- ARGUMENTS
--      inGeoRaster    - GeoRaster object.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      expression     - A math expression used to classify cell values, the
--                       syntax details are explained in GeoRaster Manual
--      rangeArray     - A number array, which defines ranges to classify cell
--                       values, it must have at least one element.
--      valueArray     - A number array, which defines target cell value for
--                       each range. it's length must be "length of rangeArray"+1
--      storageParam   - A string specifying storage parameters for the copy
--                       The details are explained in GeoRaster Manual
--      outGeoRaster   - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
-- RETURNS
--
PROCEDURE classify
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam   IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE classify
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam   IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE classify
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN     VARCHAR2 DEFAULT NULL
);

PROCEDURE classify
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0
);

PROCEDURE classify
(
   inGeoRaster  IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false'
);

-- NAME:
--      classify procedure
--
-- DESCRIPTION
--      Generate a new raster either in a GeoRaster object or a single BLOB
-- after applying classification operation on the source GeoRaster objects.
--
-- ARGUMENTS
--      georArray      - An array of GeoRaster objects.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      expression     - A math expression used to classify cell values, the
--                       syntax details are explained in GeoRaster Manual
--      rangeArray     - A number array, which defines ranges to classify cell
--                       values, it must have at least one element.
--      valueArray     - A number array, which defines target cell value for
--                       each range. it's length must be "length of rangeArray"+1
--      storageParam   - A string specifying storage parameters for the copy
--                       The details are explained in GeoRaster Manual
--      outGeoRaster   - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
-- RETURNS
--
PROCEDURE classify
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);
PROCEDURE classify
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam IN     VARCHAR2 DEFAULT NULL
);
PROCEDURE classify
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN     VARCHAR2 DEFAULT NULL
);

PROCEDURE classify
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0
);
PROCEDURE classify
(
   georArray    IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   expression   IN      VARCHAR2,
   rangeArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   valueArray   IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false'
);
--
-- NAME:
--      diff procedure
--
-- DESCRIPTION
--      generate a new raster from two input georaster objects
--      and diff operations, the new raster is either in a georaster
--      object or a single BLOB based on the parameter storageParam.
--
-- ARGUMENTS
--      geor            - The first input GeoRaster object.
--      geor1           - The second input GeoRaster object.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      storageParam    - A string specifying storage parameters for the output GeoRaster object
--                        The details are explained in GeoRaster Manual
--      outGeoRaster    - The output GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then treat nodata specially
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is '>1',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
--

PROCEDURE diff
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE diff
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN      VARCHAR2 DEFAULT NULL
);


PROCEDURE diff
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob    IN OUT  BLOB,
   outArea       OUT     MDSYS.SDO_GEOMETRY,
   outWindow     OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0
);

PROCEDURE diff
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   storageParam  IN      VARCHAR2,
   rasterBlob    IN OUT  BLOB,
   outArea       OUT     MDSYS.SDO_GEOMETRY,
   outWindow     OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false'
);

--
-- NAME:
--      over procedure
--
-- DESCRIPTION
--      generate a new raster from two input georaster objects
--      and over operations, the new raster is either in a georaster
--      object or a single BLOB based on the parameter storageParam.
--
-- ARGUMENTS
--      geor            - The first input GeoRaster object.
--      geor1           - The second input GeoRaster object.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      storageParam    - A string specifying storage parameters for the output GeoRaster object
--                        The details are explained in GeoRaster Manual
--      outGeoRaster    - The output GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata          - if 'true', then treat nodata specially
--                        if 'false',then treat all nodata as regular data.
--      nodataValu e    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam   - specify if executing operations in parallel if
--                        possible, but note if parameter parallelParam is '>1',
--                        then some execution units of this procedure will run
--                        as autonomous transactions, that means some changes
--                        are submitted and can't be rollback.
--                        You can fully rollback all of your changes if
--                        parameter parallelParam is 'false'.
--
--
PROCEDURE over
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE over
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE over
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0
);

PROCEDURE over
(
   geor          IN      MDSYS.SDO_GEORASTER,
   geor1         IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false'
);

--
-- NAME:
--      rasterMathOp procedure
--
-- DESCRIPTION
--      generate a new raster from input georaster objects
--      and math operations, the new raster is either in a georaster
--      object or a single BLOB based on the parameter storageParam.
--
-- ARGUMENTS
--      inGeoRaster     - The source SDO_GEORASTER object
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      operation       - An array of varying length Oracle STRING,each STRING
--                        is a valid expression, which is mapping to a target
--                        band in the target georaster object, and specifies
--                        how to calculate cell value based on source georaster
--                        objects.
--      storageParam    - A string specifying storage parameters for the copy
--                        The details are explained in GeoRaster Manual
--      outGeoRaster    - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
--
PROCEDURE rasterMathOp
(
   inGeoRaster   IN      MDSYS.SDO_GEORASTER,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE rasterMathOp
(
   inGeoRaster   IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE rasterMathOp
(
   inGeoRaster   IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN      VARCHAR2 DEFAULT NULL
);


PROCEDURE rasterMathOp
(
   inGeoRaster   IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0
);

PROCEDURE rasterMathOp
(
   inGeoRaster   IN      MDSYS.SDO_GEORASTER,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false'
);

--
-- NAME:
--      rasterMathOp procedure
--
-- DESCRIPTION
--      generate a new raster from input georaster objects
--      and math operations, the new raster is either in a georaster
--      object or a single BLOB based on the parameter storageParam.
--
-- ARGUMENTS
--      inGeoRasters    - GeoRaster cursor.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      operation       - An array of varying length Oracle STRING,each STRING
--                        is a valid expression, which is mapping to a target
--                        band in the target georaster object, and specifies
--                        how to calculate cell value based on source georaster
--                        objects.
--      storageParam    - A string specifying storage parameters for the copy
--                        The details are explained in GeoRaster Manual
--      outGeoRaster    - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
--
PROCEDURE rasterMathOp
(
   inGeoRasters  IN      SYS_REFCURSOR,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);
PROCEDURE rasterMathOp
(
   inGeoRasters  IN      SYS_REFCURSOR,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);
PROCEDURE rasterMathOp
(
   inGeoRasters  IN      SYS_REFCURSOR,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN      VARCHAR2 DEFAULT NULL
);
PROCEDURE rasterMathOp
(
   inGeoRasters  IN      SYS_REFCURSOR,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0
);
PROCEDURE rasterMathOp
(
   inGeoRasters  IN      SYS_REFCURSOR,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false'
);
--
-- NAME:
--      rasterMathOp procedure
--
-- DESCRIPTION
--      generate a new raster from input georaster objects
--      and math operations, the new raster is either in a georaster
--      object or a single BLOB, based on the parameter storageParam.
--
-- ARGUMENTS
--      georArray       - An array of GeoRaster objects.
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      operation       - An array of varying length Oracle STRING,each STRING
--                        is a valid expression, which is mapping to a target
--                        band in the target georaster object, and specifies
--                        how to calculate cell value based on source georaster
--                        objects.
--      storageParam    - A string specifying storage parameters for the copy
--                        The details are explained in GeoRaster Manual
--      outGeoRaster    - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and can't be rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
--
PROCEDURE rasterMathOp
(
   georArray     IN      MDSYS.SDO_GEORASTER_ARRAY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);
PROCEDURE rasterMathOp
(
   georArray     IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);
PROCEDURE rasterMathOp
(
   georArray     IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   outGeoraster  IN OUT  MDSYS.SDO_GEORASTER,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE rasterMathOp
(
   georArray     IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea      IN      MDSYS.SDO_NUMBER_ARRAY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0
);
PROCEDURE rasterMathOp
(
   georArray     IN      MDSYS.SDO_GEORASTER_ARRAY,
   cropArea      IN      MDSYS.SDO_GEOMETRY,
   operation     IN      MDSYS.SDO_STRING2_ARRAY,
   storageParam  IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   nodata        IN      VARCHAR2 DEFAULT 'false',
   nodataValue   IN      NUMBER default 0,
   polygonClip   IN      VARCHAR2 DEFAULT 'false'
);


--
-- NAME:
--      rasterMathOp procedure
--
-- DESCRIPTION
--      generate a new raster from two or one georaster objects
--      and math operations, the new raster is either in a georaster
--      object or a single BLOB, based on the parameter storageParam.
--
-- ARGUMENTS
--      geoRaster0     - The left operand
--      geoRaster1     - The right operand
--      cropArea       - Crop area definition. If the SDO_GEOMETRY object has
--                       a non-null SRID, the source GeoRaster objects must be
--                       georeferenced; otherwise, the source GeoRaster objects
--                       can be georeferenced or non-georeferenced.
--                       If polygonClip is FALSE, the MBR of the cropArea is
--                       used to crop the data. If polygonClip is TRUE,
--                       the geometry of the cropArea is used to crop the data.
--
--                       If the data type is SDO_NUMBER_ARRAY, the parameter
--                       identifies the upper-left (row, column) and
--                       lower-right (row, column) coordinates of a rectangular
--                       window, and raster space is assumed.
--      constant       - constant value for some operators like addConst,divideConst.
--      operator       - operator which should be one of math operators defined in the package
--      storageParam   - A string specifying storage parameters for the target georaster object
--                       The details are explained in GeoRaster Manual
--      outGeoRaster   - The new GeoRaster Object
--      rasterBlob     - The output GeoRaster data in BLOB without metadata
--      outArea        - An SDO_GEOMETRY object containing the MBR (minimum
--                       bounding rectangle) in the model coordinate system of
--                       the resulting object.
--      outWindow      - An SDO_NUMBER_ARRAY object identifying the coordinates
--                       of the upper-left and lower-right corners of the
--                       output window in the cell space.
--      bgValues       - background values for sparse data
--      nodata         - if 'true', then assign nodataValue to all nodata pixels in the target georaster
--                       if 'false',then treat all nodata as regular data.
--      nodataValue    - nodata value in the target georaster object,if nodataValue is null then 0 is used for nodataValue
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and you can't rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
-- RETURNS
--

PROCEDURE rasterMathOp
(
   georaster0   IN      MDSYS.SDO_GEORASTER,
   georaster1   IN      MDSYS.SDO_GEORASTER,
   constant     IN      NUMBER,
   operator     IN      PLS_INTEGER,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE rasterMathOp
(
   georaster0   IN      MDSYS.SDO_GEORASTER,
   georaster1   IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   constant     IN      NUMBER,
   operator     IN      PLS_INTEGER,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   parallelParam IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE rasterMathOp
(
   georaster0   IN      MDSYS.SDO_GEORASTER,
   georaster1   IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   constant     IN      NUMBER,
   operator     IN      PLS_INTEGER,
   storageParam IN      VARCHAR2,
   outGeoraster IN OUT  MDSYS.SDO_GEORASTER,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN      VARCHAR2 DEFAULT NULL
);


PROCEDURE rasterMathOp
(
   georaster0   IN      MDSYS.SDO_GEORASTER,
   georaster1   IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   constant     IN      NUMBER,
   operator     IN      PLS_INTEGER,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0
);

PROCEDURE rasterMathOp
(
   georaster0   IN      MDSYS.SDO_GEORASTER,
   georaster1   IN      MDSYS.SDO_GEORASTER,
   cropArea     IN      MDSYS.SDO_GEOMETRY,
   constant     IN      NUMBER,
   operator     IN      PLS_INTEGER,
   storageParam IN      VARCHAR2,
   rasterBlob   IN OUT  BLOB,
   outArea      OUT     MDSYS.SDO_GEOMETRY,
   outWindow    OUT     MDSYS.SDO_NUMBER_ARRAY,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   nodataValue  IN      NUMBER default 0,
   polygonClip  IN      VARCHAR2 DEFAULT 'false'
);

--
-- NAME:
--      rasterUpdate procedure
--
-- DESCRIPTION
--       Based on conditions and expressions to update raster cellValue.
--       The "condition" parameter is a array of boolean expressions,
--       the "values" parameter is a array of arrays of math expressions,
--       for each pixel, if a "condition" is true, then it's value
--       will get updated based on calculation of corresponding array of
--       math expression.
--
--
-- ARGUMENTS
--      geoRaster      - The SDO_GEORASTER object to be updated based on conditions
--      pyramidLevel   - specifiy which pyramid level gets updated, if null, then all
--                       pyramid levels get updated
--      condition      - A array of boolean expressions to pick pixels, the
--                       syntax details are explained in GeoRaster Manual
--      values         - A array of arrays of math expressions,the outer array is
--                       corresponding to each conditions, and inner array is
--                       corresponding to each band
--      bgValues       - background values
--      nodata         - if 'true', then keep original value for all nodata
--                       if 'false',then treat nodata as regular data.
--      parallelParam     - specify if executing operations in parallel if
--                       possible, but note if parameter parallelParam is 'true',
--                       then some execution units of this procedure will run
--                       as autonomous transactions, that means some changes
--                       are submitted and you can't rollback.
--                       You can fully rollback all of your changes if
--                       parameter parallelParam is 'false'.
--
-- RETURNS
--
PROCEDURE rasterUpdate
(
   geoRaster    IN out  MDSYS.SDO_GEORASTER,
   pyramidLevel IN      NUMBER,
   conditions   IN      MDSYS.SDO_STRING2_ARRAY,
   vals         IN      MDSYS.SDO_STRING2_ARRAYSET,
   bgValues     IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata       IN      VARCHAR2 DEFAULT 'false',
   parallelParam IN     VARCHAR2 DEFAULT NULL
);

PROCEDURE rasterUpdate
(
   geoRaster      IN out  MDSYS.SDO_GEORASTER,
   pyramidLevel   IN      NUMBER,
   targetArea     IN      MDSYS.SDO_NUMBER_ARRAY,
   conditions     IN      MDSYS.SDO_STRING2_ARRAY,
   vals           IN      MDSYS.SDO_STRING2_ARRAYSET,
   bgValues       IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata         IN      VARCHAR2 DEFAULT 'false',
   parallelParam  IN      VARCHAR2 DEFAULT NULL
);

PROCEDURE rasterUpdate
(
   geoRaster      IN out  MDSYS.SDO_GEORASTER,
   pyramidLevel   IN      NUMBER,
   targetArea     IN      MDSYS.SDO_GEOMETRY,
   conditions     IN      MDSYS.SDO_STRING2_ARRAY,
   vals           IN      MDSYS.SDO_STRING2_ARRAYSET,
   bgValues       IN      MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
   nodata         IN      VARCHAR2 DEFAULT 'false',
   polygonClip    IN      VARCHAR2 DEFAULT 'false',
   parallelParam  IN      VARCHAR2 DEFAULT NULL
);


--
-- NAME:
--      isOverlap
--
-- DESCRIPTION
--       This helper function will check if two georaster objects have .
--       same row/column dimension sizes, and if they are overlapped in
--       the model space if they are georeferenced
--
--
-- ARGUMENTS
--      geoRaster1      - The SDO_GEORASTER 1
--      geoRaster2      - The SDO_GEORASTER 2
--      tolerance       - Specifies the tolerance used to decide if two pixels in cell space are
--                        overlapped in the model spce. The value should be between 0
--                        and 1 and is in pixel unit. for example, 0.5 means half pixel.
--
-- RETURNS
--   'TRUE' if overlapped, otherwise 'FALSE'

FUNCTION isOverlap
(
  georaster1 IN MDSYS.SDO_GEORASTER,
  georaster2 IN MDSYS.SDO_GEORASTER,
  tolerance  IN NUMBER default 0.5
)
RETURN VARCHAR2  DETERMINISTIC PARALLEL_ENABLE;

--
-- NAME:
--      isOverlap
--
-- DESCRIPTION
--       This helper function will check if an array of georaster objects have .
--       same row/column dimension sizes, and if they are overlapped in
--       the model space if they are georeferenced
--
--
-- ARGUMENTS
--      geor_array      - The SDO_GEORASTER array
--      tolerance       - Specifies the tolerance used to decide if two pixels in cell space are
--                        overlapped in the model spce. The value should be between 0
--                        and 1 and is in pixel unit. for example, 0.5 means half pixel.
--
-- RETURNS
--   'TRUE' if overlapped, otherwise 'FALSE'

FUNCTION isOverlap
(
  georArray  IN MDSYS.SDO_GEORASTER_ARRAY,
  tolerance  IN NUMBER default 0.5
)
RETURN VARCHAR2  DETERMINISTIC PARALLEL_ENABLE;

--
-- NAME:
--      isOverlap
--
-- DESCRIPTION
--       This helper function will check if a cursor of georaster objects have .
--       same row/column dimension sizes, and if they are overlapped in
--       the model space if they are georeferenced
--
--
-- ARGUMENTS
--      geor_cur        - The SDO_GEORASTER cursor
--      tolerance       - Specifies the tolerance used to decide if two pixels in cell space are
--                        overlapped in the model spce. The value should be between 0
--                        and 1 and is in pixel unit. for example, 0.5 means half pixel.
--
-- RETURNS
--   'TRUE' if overlapped, otherwise 'FALSE'

FUNCTION isOverlap
(
  geor_cur   IN SYS_REFCURSOR,
  tolerance  IN NUMBER default 0.5
)
RETURN VARCHAR2  DETERMINISTIC PARALLEL_ENABLE;


END SDO_GEOR_RA;
/

