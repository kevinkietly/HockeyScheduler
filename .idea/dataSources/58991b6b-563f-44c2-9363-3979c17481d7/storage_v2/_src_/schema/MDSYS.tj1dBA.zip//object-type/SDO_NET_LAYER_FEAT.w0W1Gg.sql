create TYPE SDO_NET_LAYER_FEAT AS OBJECT
    (
      feature_layer_id NUMBER,
      feature_id       NUMBER
    )
/

