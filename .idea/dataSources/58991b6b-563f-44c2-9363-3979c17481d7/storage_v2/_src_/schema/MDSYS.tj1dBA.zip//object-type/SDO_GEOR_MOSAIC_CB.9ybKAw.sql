create TYPE       sdo_geor_mosaic_cb wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
88 8d
aH3z6VmjBSJHhOcoTGP/cxV2uokwg5n0dLhcFtz60K6u15YYcteW3EdZSq7cCbh0K6W/m8Ay
y8xQjwmm4a4fRFelmYEywLIlzKYMV62Svg6hqZVqdhB0LSem8gRr8rjeo4KmpkQAHC8=
/

