create PACKAGE       SDO_ROUTER_PARTITION AUTHID current_user AS
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  FUNCTION adjust_m(start_m IN NUMBER, end_m IN NUMBER, m IN NUMBER)
    RETURN NUMBER;

  FUNCTION get_pid(m IN NUMBER, pid IN NUMBER)
    RETURN NUMBER;

  FUNCTION min_eigenvector(sum_x2 IN NUMBER, sum_y2 IN NUMBER, sum_xy IN NUMBER)
    RETURN mdsys.vector_2d;

  PROCEDURE cleanup_router(all_tables IN BOOLEAN DEFAULT TRUE);

  PROCEDURE create_sdo_router_log_dir(
             router_schema    IN VARCHAR2,
             new_dir_path     IN VARCHAR2 DEFAULT NULL);

  PROCEDURE partition_router(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                        max_v_no IN NUMBER DEFAULT 10000,
                        driving_side IN VARCHAR2 := 'R',
                        network_name IN VARCHAR := 'ROUTER_NETWORK',
                        max_memory IN NUMBER := 1.75,
                        cleanup IN BOOLEAN DEFAULT TRUE,
                        use_securefiles IN BOOLEAN DEFAULT TRUE,
                        generate_11g_restrictions IN BOOLEAN DEFAULT TRUE);

  PROCEDURE validate_sdo_router_log_dir(log_file_name IN VARCHAR2 := 'sdo_router_partition.log');

  PROCEDURE create_border_data(
                      log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      cleanup IN BOOLEAN DEFAULT TRUE);

  PROCEDURE create_timezone_data(
                      log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      cleanup IN BOOLEAN DEFAULT TRUE);

  PROCEDURE create_trucking_data(
                      log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      cleanup IN BOOLEAN DEFAULT TRUE);

  PROCEDURE create_turn_restriction_data(
                      log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      cleanup IN BOOLEAN DEFAULT TRUE);

  PROCEDURE dump_partitions(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      start_pid IN NUMBER DEFAULT 0,
                      end_pid IN NUMBER DEFAULT -1,
                      verbose IN BOOLEAN DEFAULT FALSE);

  PROCEDURE dump_turns_in_blobs(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                              table_name IN VARCHAR2 := 'prohibited_turns',
                              start_pid IN NUMBER DEFAULT 1,
                              end_pid IN NUMBER DEFAULT -1,
                              append_data IN BOOLEAN DEFAULT FALSE);

  PROCEDURE dump_border_data(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      start_pid IN NUMBER DEFAULT 0,
                      end_pid IN NUMBER DEFAULT -1);

  PROCEDURE dump_timezone_data(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      start_pid IN NUMBER DEFAULT 0,
                      end_pid IN NUMBER DEFAULT -1);

  PROCEDURE dump_trucking_data(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      start_pid IN NUMBER DEFAULT 0,
                      end_pid IN NUMBER DEFAULT -1,
                      skip_unsupported IN BOOLEAN DEFAULT TRUE);

  PROCEDURE dump_turn_restriction_data(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      start_pid IN NUMBER DEFAULT 0,
                      end_pid IN NUMBER DEFAULT -1,
                      dump_soft_restrictions IN BOOLEAN DEFAULT FALSE);

  PROCEDURE validate_partitions(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                      start_pid IN NUMBER DEFAULT 0,
                      end_pid IN NUMBER DEFAULT -1,
                      verbose IN BOOLEAN DEFAULT FALSE);

   PROCEDURE gather_table_stats(table_name IN VARCHAR2);

   PROCEDURE get_version(log_file_name IN VARCHAR2 := 'sdo_router_partition.log');

  PROCEDURE create_router_network(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                                  network_name  IN VARCHAR2 := 'ROUTER_NETWORK');

  PROCEDURE delete_router_network(log_file_name IN VARCHAR2 := 'sdo_router_partition.log',
                                  network_name  IN VARCHAR2 := 'ROUTER_NETWORK',
                                  log_delete IN BOOLEAN := TRUE);

  PROCEDURE elocation_partition_router (logfile_name  IN VARCHAR2,
                                        blob_format IN VARCHAR2) ;

  PROCEDURE elocation_border_data (logfile_name IN VARCHAR2);

  PROCEDURE elocation_timezone_data (logfile_name IN VARCHAR2) ;

  PROCEDURE elocation_trucking_data (logfile_name IN VARCHAR2) ;

  PROCEDURE elocation_turn_restrict_data (logfile_name IN VARCHAR2) ;

  PROCEDURE elocation_dump_partition (logfile_name in VARCHAR2,
                                      start_pid in NUMBER,
                                      end_pid in NUMBER,
                                      verbose in BOOLEAN,
                                      is10g in BOOLEAN) ;

  PROCEDURE elocation_dump_blob_turns(logfile_name in VARCHAR2,
				      table_name in VARCHAR2,
				      start_pid in NUMBER,
                                      end_pid in NUMBER,
                                      append_data in BOOLEAN);

  PROCEDURE elocation_dump_border_data (logfile_name IN VARCHAR2,
                                  start_pid IN NUMBER,
                                  end_pid IN NUMBER) ;

  PROCEDURE elocation_dump_timezone_data (logfile_name IN VARCHAR2,
                                         start_pid IN NUMBER,
                                         end_pid IN NUMBER) ;

  PROCEDURE elocation_dump_trucking_data (logfile_name IN VARCHAR2,
                                         start_pid IN NUMBER,
                                         end_pid IN NUMBER,
                                         skip_unsupported IN BOOLEAN) ;

  -- PLSQL limit, full name elocation_dump_turn_restrict_data
  PROCEDURE elocation_dump_turn_restrict (logfile_name IN VARCHAR2,
                                         start_pid IN NUMBER,
                                         end_pid IN NUMBER,
                                         dump_soft_restrictions IN BOOLEAN) ;

  PROCEDURE elocation_validate_partition (logfile_name in VARCHAR2,
                                          start_pid in NUMBER,
                                          end_pid in NUMBER,
                                          verbose in BOOLEAN,
                                          is10g in BOOLEAN) ;

  PROCEDURE build_turn_restrictions (logdir in VARCHAR2,
                                     drivingside in VARCHAR2) ;

  PROCEDURE elocation_validate_logfile(logfile_name  IN VARCHAR2,
                                     schema_name IN VARCHAR2) ;

  FUNCTION get_edge_info(edge_ids       IN  MDSYS.sdo_list_type,
                         to_edge_ids    OUT MDSYS.sdo_list_type,
                         rets           OUT mdsys.string_array,
                         angle_segments OUT MDSYS.sdo_list_type)
  RETURN mdsys.string_array ;

  FUNCTION get_edge_info(edge_ids  IN  sdo_list_type,
                         to_edge_ids    OUT sdo_list_type,
                         rets           OUT mdsys.string_array,
                         angle_segments OUT sdo_list_type,
                         edge_ids_reordered OUT sdo_list_type)
  RETURN mdsys.string_array;

  FUNCTION get_geometry_info(edge_ids       IN  MDSYS.sdo_list_type,
                             merged_coords  OUT MDSYS.sdo_list_type)
  RETURN NUMBER;

  FUNCTION get_geometry_info (edge_ids IN  sdo_list_type,
                              merged_coords OUT sdo_list_type,
                              edge_ids_reordered OUT sdo_list_type)
  RETURN NUMBER;

  FUNCTION get_geometry_info_link_lvl(edge_ids       IN  MDSYS.sdo_list_type,
                                      merged_coords  OUT MDSYS.sdo_list_type)
  RETURN NUMBER;

  FUNCTION get_ferry_edge_ids(partition_id IN number,
                              edge_ids     OUT MDSYS.sdo_list_type)
  RETURN NUMBER;

  FUNCTION get_avoid_zone_edge_ids(avoid_zone_coords IN sdo_number_array,
                                   edge_ids OUT number_array_2d)
  RETURN NUMBER;

END SDO_ROUTER_PARTITION;
/

