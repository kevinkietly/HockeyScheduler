create view USER_SDO_NETWORK_HISTORIES as
SELECT  network, node_history_table, link_history_table, node_trigger, link_trigger
    FROM  mdsys.sdo_network_histories
    WHERE owner = sys_context('USERENV', 'CURRENT_USER')
/

