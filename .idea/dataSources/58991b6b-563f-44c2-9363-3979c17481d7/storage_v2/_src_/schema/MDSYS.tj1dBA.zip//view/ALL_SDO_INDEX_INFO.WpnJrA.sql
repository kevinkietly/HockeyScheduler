create view ALL_SDO_INDEX_INFO as
select SDO_INDEX_OWNER, SDO_INDEX_NAME index_name, table_owner, table_name,
       REPLACE(sdo_column_name, '"')  column_name,
       SDO_INDEX_TYPE, SDO_INDEX_TABLE, SDO_INDEX_STATUS, SDO_INDEX_PARTITION
 from mdsys.all_sdo_index_metadata, SYS.all_indexes
 where index_name = sdo_index_name and owner=sdo_index_owner
/

