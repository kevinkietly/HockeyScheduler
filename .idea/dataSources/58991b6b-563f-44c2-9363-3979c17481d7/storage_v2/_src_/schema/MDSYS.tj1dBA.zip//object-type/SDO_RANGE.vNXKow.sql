create TYPE SDO_RANGE
                                                                      
AS OBJECT (lb NUMBER, ub NUMBER)
/

