create type rdfctx_extractor authid current_user as object (

      extr_type  VARCHAR2(32),

      member procedure startDriver,

      member function getDescription return VARCHAR2,

      -- RDF/XML,RDF/XML-ESC, etc
      member function rdfReturnType return VARCHAR2,
      -- In some cases, the rdf/xml text has escape sequences for the
      -- XML tags which makes them invalid XML. Hence a generic CLOB type is
      -- is used.

      member function extractRdf(document CLOB,
                                 docId    VARCHAR2) return CLOB,

      member procedure closeDriver

    ) not instantiable not final
 alter type rdfctx_extractor
      add member function getContext(attribute VARCHAR2) return VARCHAR2
      cascade
 alter type rdfctx_extractor
      add member function extractRdf(document CLOB,
                                     docId    VARCHAR2,
                                     params   VARCHAR2,
                                     options  VARCHAR2 default NULL) return CLOB
      cascade
 alter type rdfctx_extractor
      add member function batchExtractRdf(docCursor        SYS_REFCURSOR,
                                     extracted_info_table  VARCHAR2,
                                     params                VARCHAR2,
                                     partition_name        VARCHAR2 default NULL,
                                     docId                 VARCHAR2 default NULL,
                                     preferences           SYS.XMLType default NULL,
                                     options               VARCHAR2 default NULL) return CLOB
      cascade
/

