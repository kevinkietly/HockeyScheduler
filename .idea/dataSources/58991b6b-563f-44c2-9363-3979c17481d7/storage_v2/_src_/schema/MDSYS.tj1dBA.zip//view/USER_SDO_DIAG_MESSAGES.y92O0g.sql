create view USER_SDO_DIAG_MESSAGES as
select SDO_USER,
        SDO_SID,
        SDO_SYSTEM_NAME,
        SDO_TIMESTAMP,
        SDO_SEQUENCE,
        SDO_LEVEL,
        SDO_MESSAGE
 from MDSYS.SDO_DIAG_MESSAGES_TABLE
 where sdo_user = sys_context('userenv', 'CURRENT_USER')
/

