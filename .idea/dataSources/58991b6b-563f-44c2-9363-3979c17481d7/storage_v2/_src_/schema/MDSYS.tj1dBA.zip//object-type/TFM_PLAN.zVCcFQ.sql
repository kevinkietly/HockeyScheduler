create TYPE       TFM_PLAN
AS OBJECT (
  THE_PLAN MDSYS.SDO_TFM_CHAIN,

  CONSTRUCTOR FUNCTION TFM_PLAN
      RETURN SELF AS RESULT,

  CONSTRUCTOR FUNCTION TFM_PLAN(
    source_srid NUMBER)
      RETURN SELF AS RESULT,

  MEMBER PROCEDURE ADD_STEP(
    srid_source  NUMBER,
    tfm         NUMBER,
    srid_target  NUMBER),

  MEMBER FUNCTION GET_NUM_STEPS
      RETURN NUMBER,

  MEMBER FUNCTION GET_STEP(
    num           IN NUMBER,
    source_srid   OUT NUMBER,
    target_srid   OUT NUMBER) RETURN NUMBER,

  MEMBER FUNCTION expand_concat_chain_element(
    source_srid   IN NUMBER,
    chain_element IN NUMBER,
    target_srid   IN NUMBER)
      RETURN TFM_PLAN,

  MEMBER PROCEDURE expand_for_chain_element_core(
    srid_source  IN NUMBER,
    chain_element IN NUMBER,
    srid_target  IN NUMBER),

  MEMBER PROCEDURE expand_inv_chain_element_core(
    srid_source  IN NUMBER,
    chain_element IN NUMBER,
    srid_target  IN NUMBER),

  MEMBER PROCEDURE expand_chain_element_core(
    srid_source  IN NUMBER,
    chain_element IN NUMBER,
    srid_target  IN NUMBER),

  MEMBER FUNCTION expand_concat_chain_elements
      RETURN TFM_PLAN
);
/

