create Type proc_msg as object (
      object_id     INTEGER,
      time          TIMESTAMP,
      x             NUMBER,
      y             NUMBER,
      region_id     INTEGER,
      alert_when    VARCHAR2(2))
/

