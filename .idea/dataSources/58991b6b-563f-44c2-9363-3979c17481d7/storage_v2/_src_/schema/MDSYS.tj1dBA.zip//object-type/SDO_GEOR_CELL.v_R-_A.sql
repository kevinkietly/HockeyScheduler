create TYPE       SDO_GEOR_CELL
                                                                      
AS OBJECT
(
   value         number,
   pyramidLevel  number,
   rowNumber     number,
   colNumber     number,
   layerNumber   number,
   geom          sdo_geometry
)
/

