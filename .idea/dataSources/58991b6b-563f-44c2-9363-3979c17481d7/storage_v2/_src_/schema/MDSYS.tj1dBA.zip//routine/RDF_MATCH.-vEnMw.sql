create FUNCTION RDF_MATCH wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
38b 15c
dCp+jq9FrgJ+5gcX6Qij/ely1icwgzu3r9w2qHRAAPiOdip/HDQj/OYXB7Q+tG+xrQj5IO5L
MYh4ti6FxVvT+VAokni1abS6WYoUdDLhToZqEjVYVUUiZ+TnmwaDyxlpblGtj74jEEW/APby
+6HEXlCTT3K7kIHc444VHRb8y8IpkHYOU8zirR/tt2WiJyuKWfxWSnalA+U3lO3AV4+mAkdS
qPwUY2hAsPiTVWd7nl0IB4hM0v3jdLZADfmq4xGwFCAqkDAI+ZZV4hozxg/PHuEA0cQ2O+eY
PBnxGKY5YspCoZnzCelAHWvZf+/p1I8YYCI/wTvUPl4NsZiWKvIDmg==
/

