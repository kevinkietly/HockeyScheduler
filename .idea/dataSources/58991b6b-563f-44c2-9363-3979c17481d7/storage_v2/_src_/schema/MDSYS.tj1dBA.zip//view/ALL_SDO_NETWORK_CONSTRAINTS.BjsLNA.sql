create view ALL_SDO_NETWORK_CONSTRAINTS as
SELECT  sdo_owner owner, constraint, description, class_name, class     FROM  sdo_network_constraints
/

