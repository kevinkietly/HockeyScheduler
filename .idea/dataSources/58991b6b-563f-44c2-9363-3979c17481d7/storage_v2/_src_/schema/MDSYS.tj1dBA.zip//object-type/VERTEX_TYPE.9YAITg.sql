create type vertex_type as object
(X  number,
 Y  number,
 Z  number,
 W  number,
 v5 number,
 v6 number,
 v7 number,
 v8 number,
 v9 number,
 v10 number,
 v11 number,
 ID number,
 Constructor
 Function vertex_type(x  In number,
                     y  In number,
                     id In number)
 Return Self As Result,
Constructor
Function vertex_type(x In number,
                     y In number,
                     z In number,
                     w in number)
Return Self As Result,
Constructor
Function vertex_type(x In number,
                     y In number,
                     z In number,
                     w in number,
                     id in number)
Return Self As Result );
/

