create TYPE sdo_rdf_triple_s
                                                                          
  authid current_user
  AS OBJECT
       (rdf_c_id NUMBER,
        rdf_m_id NUMBER,
        rdf_s_id NUMBER,
        rdf_p_id NUMBER,
        rdf_o_id NUMBER,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object VARCHAR2)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        sub_or_bn VARCHAR2,
                                        property VARCHAR2,
                                        obj_or_bn VARCHAR2,
                                        bn_m_id NUMBER)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        sub_or_bn VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB,
                                        bn_m_id NUMBER)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        rdf_t_id NUMBER)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        rdf_t_id NUMBER,
                                        property VARCHAR2,
                                        object VARCHAR2)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        rdf_t_id NUMBER)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        s_rdf_t_id NUMBER,
                                        property VARCHAR2,
                                        o_rdf_t_id NUMBER)
        RETURN SELF AS RESULT DETERMINISTIC,
        CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        reif_subject VARCHAR2,
                                        reif_property VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object VARCHAR2)
        RETURN SELF AS RESULT DETERMINISTIC,
        MEMBER FUNCTION get_triple RETURN SDO_RDF_TRIPLE DETERMINISTIC,
        MEMBER FUNCTION get_object RETURN CLOB DETERMINISTIC,
        MEMBER FUNCTION get_subject RETURN VARCHAR2 DETERMINISTIC,
        MEMBER FUNCTION get_property RETURN VARCHAR2 DETERMINISTIC
        )
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_obj_value RETURN VARCHAR2
      DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION is_object_clob RETURN VARCHAR2
      DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_model RETURN VARCHAR2
      DETERMINISTIC CASCADE
 
       ALTER TYPE sdo_rdf_triple_s
       DROP MEMBER FUNCTION get_model RETURN VARCHAR2
       DETERMINISTIC CASCADE
 
       ALTER TYPE sdo_rdf_triple_s
       DROP MEMBER FUNCTION get_triple RETURN SDO_RDF_TRIPLE
       DETERMINISTIC CASCADE
 
       ALTER TYPE sdo_rdf_triple_s
       DROP MEMBER FUNCTION get_subject RETURN VARCHAR2
       DETERMINISTIC CASCADE
 
       ALTER TYPE sdo_rdf_triple_s
       DROP MEMBER FUNCTION get_property RETURN VARCHAR2
       DETERMINISTIC CASCADE
 
       ALTER TYPE sdo_rdf_triple_s
       DROP MEMBER FUNCTION get_obj_value RETURN VARCHAR2
       DETERMINISTIC CASCADE
 
       ALTER TYPE sdo_rdf_triple_s
       DROP MEMBER FUNCTION get_object RETURN CLOB
       DETERMINISTIC CASCADE
 
       ALTER TYPE sdo_rdf_triple_s
       DROP MEMBER FUNCTION is_object_clob RETURN VARCHAR2
       DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_model (
            network_owner varchar2 default NULL
          , network_name varchar2 default NULL
          )
          RETURN VARCHAR2 DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_triple (
            network_owner varchar2 default NULL
          , network_name varchar2 default NULL
          )
          RETURN SDO_RDF_TRIPLE DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_subject (
            network_owner varchar2 default NULL
          , network_name varchar2 default NULL
          )
          RETURN VARCHAR2 DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_property (
            network_owner varchar2 default NULL
          , network_name varchar2 default NULL
          )
          RETURN VARCHAR2 DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_obj_value (
            network_owner varchar2 default NULL
          , network_name varchar2 default NULL
          )
          RETURN VARCHAR2 DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION get_object (
            network_owner varchar2 default NULL
          , network_name varchar2 default NULL
          )
          RETURN CLOB DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
      ADD MEMBER FUNCTION is_object_clob (
            network_owner varchar2 default NULL
          , network_name varchar2 default NULL
          )
          RETURN VARCHAR2 DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
        ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        reif_subject VARCHAR2,
                                        reif_property VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            DROP CONSTRUCTOR FUNCTION sdo_rdf_triple_s(
                                        model_name VARCHAR2,
                                        reif_subject VARCHAR2,
                                        reif_property VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object VARCHAR2)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            DROP CONSTRUCTOR FUNCTION sdo_rdf_triple_s(
                                        model_name VARCHAR2,
                                        reif_subject VARCHAR2,
                                        reif_property VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            DROP CONSTRUCTOR FUNCTION sdo_rdf_triple_s(
                                        model_name VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object VARCHAR2)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            DROP CONSTRUCTOR FUNCTION sdo_rdf_triple_s(
                                        model_name VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
        ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object VARCHAR2,
                                        network_owner VARCHAR2 default NULL,
                                        network_name  VARCHAR2 default NULL)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
        ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB,
                                        network_owner VARCHAR2 default NULL,
                                        network_name  VARCHAR2 default NULL)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_id NUMBER,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object VARCHAR2,
                                        in_mode VARCHAR2)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_id NUMBER,
                                        subject VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB,
                                        in_mode VARCHAR2)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_id NUMBER,
                                        sub_or_bn VARCHAR2,
                                        property VARCHAR2,
                                        obj_or_bn VARCHAR2,
                                        in_mode VARCHAR2,
                                        bn_m_id NUMBER)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_id NUMBER,
                                        sub_or_bn VARCHAR2,
                                        property VARCHAR2,
                                        object CLOB,
                                        in_mode VARCHAR2,
                                        bn_m_id NUMBER)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(
                                        model_name    VARCHAR2,
                                        nonauto       NUMBER,
                                        subject       VARCHAR2,
                                        property      VARCHAR2,
                                        object        VARCHAR2,
                                        network_owner VARCHAR2 DEFAULT NULL,
                                        network_name  VARCHAR2 DEFAULT NULL)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
  ALTER TYPE sdo_rdf_triple_s
            ADD CONSTRUCTOR FUNCTION sdo_rdf_triple_s(
                                        model_name    VARCHAR2,
                                        nonauto       NUMBER,
                                        subject       VARCHAR2,
                                        property      VARCHAR2,
                                        object        CLOB,
                                        network_owner VARCHAR2 DEFAULT NULL,
                                        network_name  VARCHAR2 DEFAULT NULL)
            RETURN SELF AS RESULT DETERMINISTIC CASCADE
/

