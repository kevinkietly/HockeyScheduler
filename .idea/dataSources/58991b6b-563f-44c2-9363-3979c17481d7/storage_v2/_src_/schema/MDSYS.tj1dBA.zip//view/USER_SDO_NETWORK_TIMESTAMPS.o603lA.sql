create view USER_SDO_NETWORK_TIMESTAMPS as
SELECT  network, table_name, last_dml_time
    FROM  mdsys.sdo_network_timestamps
    WHERE owner = sys_context('USERENV', 'CURRENT_USER')
/

