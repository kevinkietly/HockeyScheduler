create TYPE sem_sameas_rec as object (s number, e number)
/

