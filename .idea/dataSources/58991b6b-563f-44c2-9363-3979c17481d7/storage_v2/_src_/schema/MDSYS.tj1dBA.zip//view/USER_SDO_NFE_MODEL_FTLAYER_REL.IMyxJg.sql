create view USER_SDO_NFE_MODEL_FTLAYER_REL as
SELECT model_id, feature_layer_id, hierarchy_level, z_order, path_layer
  FROM MDSYS.SDO_NFE_MODEL_FTLAYER_REL
  WHERE sdo_owner = sys_context('USERENV', 'CURRENT_USER')
/

