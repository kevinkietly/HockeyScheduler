create TYPE vector_2d as OBJECT ( x NUMBER, y NUMBER);
/

